
// my dataset of 50 cheap Indian student meals. Costs are in rupees per serving (my estimate of normal shop prices).
// diet: vg = vegan, v = vegetarian, n = non-veg. Row: [name, slot, diet, kcal, protein, carbs, fat, [[ingredient, cost],...], steps]
const R=[
["Egg Bhurji & Roti","breakfast","n",480,25,38,24,[["Eggs",21],["Atta",6],["Onion & spices",5]],"Scramble eggs with onion & spices in a pan. Make rotis on a tawa."],
["Oats Banana Bowl","breakfast","v",420,15,68,9,[["Oats",15],["Milk",8],["Banana",5]],"Boil oats in milk 3 min, top with sliced banana."],
["Peanut Butter Toast","breakfast","vg",380,14,40,18,[["Bread",8],["Peanut butter",10]],"Toast bread on tawa, spread peanut butter."],
["Moong Sprouts Salad","breakfast","vg",260,16,40,2,[["Moong sprouts",12],["Onion & tomato",6],["Lemon",2]],"Mix sprouts, chopped onion, tomato, lemon and salt."],
["Poha with Peanuts","breakfast","vg",350,9,55,11,[["Poha",8],["Peanuts",6],["Onion & spices",3]],"Rinse poha, saute onion, peanuts, turmeric; mix and steam 2 min."],
["Besan Chilla","breakfast","vg",330,17,38,12,[["Besan",12],["Vegetables",5]],"Make besan batter with veggies, spread thin on a tawa and cook both sides."],
["Paneer Bhurji & Roti","breakfast","v",520,26,32,30,[["Paneer",30],["Atta",6],["Onion & spices",4]],"Crumble paneer, saute with onion & spices. Serve with roti."],
["Rava Upma","breakfast","vg",300,7,50,8,[["Rava",8],["Vegetables",5],["Oil & mustard",2]],"Roast rava, saute veggies, add 2x water and cook till thick."],
["Boiled Eggs & Banana","breakfast","n",400,26,30,20,[["Eggs",28],["Banana",5]],"Boil 4 eggs for 10 min in a kettle or pot. Eat with banana."],
["Veg Omelette & Bread","breakfast","n",400,20,30,20,[["Eggs",14],["Bread",8],["Vegetables",4]],"Whisk eggs with chopped veggies and cook as omelette."],
["Idli Sambar","breakfast","vg",330,12,62,3,[["Idli batter",12],["Sambar dal",8]],"Steam idli batter in a cooker. Boil dal with sambar powder."],
["Soy Milk Oats","breakfast","vg",400,20,55,10,[["Oats",15],["Soy milk",15]],"Cook oats in soy milk 3 min; add jaggery if you like."],
["Aloo Paratha & Curd","breakfast","v",450,12,62,16,[["Atta",6],["Potato",5],["Curd",8]],"Stuff mashed spiced potato in dough, roll and roast with little oil."],
["Soya Chunks Curry & Rice","lunch","vg",620,38,85,12,[["Soya chunks",14],["Rice",8],["Masala & onion",6]],"Soak soya 10 min, squeeze. Cook with onion-tomato masala. Serve with rice."],
["Rajma Chawal","lunch","vg",600,20,100,8,[["Rajma",14],["Rice",8],["Masala & onion",5]],"Pressure-cook soaked rajma 5 whistles with masala; serve over rice."],
["Chole Rice","lunch","vg",620,21,98,12,[["Chickpeas",14],["Rice",8],["Masala & onion",4]],"Pressure-cook soaked chickpeas with masala; serve with rice."],
["Dal Tadka & Rice","lunch","vg",560,20,92,9,[["Toor dal",12],["Rice",8],["Tadka spices & oil",5]],"Cook dal 3 whistles; temper with cumin, garlic, chilli."],
["Egg Curry & Rice","lunch","n",640,28,80,22,[["Eggs",21],["Rice",8],["Masala & onion",8]],"Boil eggs, simmer in onion-tomato gravy. Serve with rice."],
["Chicken Curry & Rice","lunch","n",650,40,75,20,[["Chicken",45],["Rice",8],["Masala & onion",8]],"Pressure-cook chicken with masala 3 whistles; serve with rice."],
["Paneer Curry & Roti","lunch","v",640,28,55,34,[["Paneer",30],["Atta",6],["Gravy ingredients",8]],"Simmer paneer cubes in tomato-onion gravy."],
["Veg Pulao & Curd","lunch","v",520,14,82,14,[["Rice",10],["Vegetables",10],["Curd",8]],"Cook rice with veggies & whole spices in a cooker."],
["Soya Pulao","lunch","vg",560,30,85,10,[["Soya chunks",12],["Rice",10],["Vegetables",8]],"Cook rice with soaked soya and veggies in a cooker."],
["Egg Fried Rice","lunch","n",560,20,80,16,[["Eggs",14],["Rice",8],["Vegetables",8]],"Scramble eggs, toss with leftover rice and veggies."],
["Sambar Rice","lunch","vg",520,16,90,8,[["Toor dal",10],["Rice",8],["Vegetables",8]],"Cook dal with veggies and sambar powder, mix with rice."],
["Curd Rice & Pickle","lunch","v",420,14,70,8,[["Rice",8],["Curd",12]],"Mash rice with curd and salt; temper with mustard."],
["Egg Biryani","lunch","n",680,26,90,22,[["Eggs",21],["Rice",12],["Biryani masala",8]],"Layer rice, masala and boiled eggs in a cooker and steam."],
["Roasted Chana & Tea","snack","v",230,12,32,5,[["Roasted chana",8],["Milk tea",5]],"Ready to eat. Brew tea in a kettle."],
["Roasted Peanuts","snack","vg",250,11,8,20,[["Peanuts",10]],"Dry roast peanuts on a tawa."],
["Banana & Peanut Butter","snack","vg",280,8,36,12,[["Banana",5],["Peanut butter",8]],"Slice banana, dip in peanut butter."],
["Sweet Corn Chaat","snack","vg",200,6,38,3,[["Sweet corn",12],["Lemon & chaat masala",3]],"Boil corn, toss with lemon & chaat masala."],
["Boiled Eggs & Tea","snack","n",220,14,3,14,[["Eggs",14],["Tea",4]],"Boil 2 eggs; make tea."],
["Sprouts Chaat","snack","vg",180,12,28,2,[["Moong sprouts",12]],"Mix sprouts with onion, tomato, lemon."],
["Sattu Drink","snack","vg",200,12,30,3,[["Sattu",8]],"Mix sattu with water, salt, lemon & roasted cumin."],
["Milk & Dates","snack","v",260,9,40,7,[["Milk",12],["Dates",6]],"Warm milk, eat with 4 dates."],
["Roasted Soya Snack","snack","vg",200,20,14,6,[["Soya chunks",10]],"Dry roast soaked soya chunks with chilli & salt."],
["Egg Sandwich","snack","n",330,18,28,15,[["Eggs",14],["Bread",8]],"Make omelette and sandwich between bread."],
["Makhana Roast","snack","vg",130,4,22,3,[["Makhana",15]],"Dry roast fox nuts with salt and pepper."],
["Boiled Chana Salad","snack","vg",220,12,34,4,[["Black chana",12]],"Boil soaked chana, toss with onion, lemon."],
["Dal Khichdi & Curd","dinner","v",520,22,80,10,[["Moong dal",8],["Rice",8],["Curd",10],["Ghee & spices",4]],"Cook rice and dal together with turmeric. Serve with curd."],
["Roti, Moong Dal & Aloo Gobi","dinner","vg",540,20,88,9,[["Moong dal",8],["Atta",6],["Vegetables",12]],"Cook dal, saute veggies, make rotis."],
["Egg Curry & Roti","dinner","n",520,26,40,26,[["Eggs",21],["Atta",6],["Masala & onion",8]],"Simmer boiled eggs in gravy; serve with roti."],
["Soya Chunks Sabzi & Roti","dinner","vg",480,36,55,10,[["Soya chunks",14],["Atta",6],["Masala & onion",6]],"Cook soaked soya with masala; serve with roti."],
["Paneer Matar & Roti","dinner","v",540,26,45,28,[["Paneer",25],["Green peas",8],["Atta",6]],"Simmer paneer & peas in gravy; serve with roti."],
["Chicken Curry & Roti","dinner","n",560,42,38,24,[["Chicken",45],["Atta",6],["Masala & onion",8]],"Pressure-cook chicken with masala; serve with roti."],
["Vegetable Dalia","dinner","vg",420,16,72,6,[["Dalia",10],["Vegetables",8],["Moong dal",6]],"Pressure-cook dalia with dal and veggies."],
["Chole & Roti","dinner","vg",520,20,80,12,[["Chickpeas",14],["Atta",6],["Masala & onion",5]],"Pressure-cook chickpeas with masala; serve with roti."],
["Egg Roll","dinner","n",430,20,38,20,[["Eggs",14],["Atta",6],["Onion & chutney",5]],"Cook egg on a roti on the tawa, roll with onion."],
["Palak Dal & Roti","dinner","vg",480,20,70,9,[["Spinach",8],["Toor dal",10],["Atta",6]],"Cook dal with chopped spinach; serve with roti."],
["Rajma & Roti","dinner","vg",540,21,85,8,[["Rajma",14],["Atta",6],["Masala & onion",6]],"Pressure-cook rajma; serve with roti."],
["Besan Kadhi & Rice","dinner","v",480,14,75,12,[["Besan",6],["Curd",8],["Rice",8]],"Whisk besan with curd and water, simmer with tadka."]
].map((r,i)=>({id:i,name:r[0],slot:r[1],diet:r[2],kcal:r[3],protein:r[4],carbs:r[5],fat:r[6],ings:r[7],steps:r[8],cost:r[7].reduce((s,x)=>s+x[1],0)}));
const CATS=[[/egg|chicken|paneer|milk|curd|tea|ghee/i,"Dairy, Eggs & Meat"],[/dal|rajma|chickpea|chana|soya|soy|moong|besan|peanut|sattu|makhana/i,"Pulses & Protein"],[/rice|atta|oats|poha|rava|bread|dalia|idli|corn/i,"Grains & Staples"],[/onion|vegetable|potato|banana|lemon|peas|spinach|tomato|dates/i,"Fresh Produce"]];
const catOf=n=>(CATS.find(c=>c[0].test(n))||[0,"Spices & Others"])[1];

// approximate preparation time (minutes), derived from the cooking method
R.forEach(r=>{const s=r.steps.toLowerCase();r.prep=/ready to eat/.test(s)?2:/pressure-cook|steam|layer/.test(s)?35:/simmer|cook dal|cook rice/.test(s)?25:/boil/.test(s)?12:/mix|toss|slice|spread|toast|dry roast/.test(s)?5:15});
// Typical hostel mess menu: [name, meal, kcal, protein, carbs, fat, diet]
const MESS=[
["Idli (3) + Sambar","breakfast",230,8,44,2,"vg"],["Poha","breakfast",250,6,45,6,"vg"],["Upma","breakfast",280,6,46,8,"vg"],["Puri + Aloo Sabzi","breakfast",450,8,55,20,"vg"],["Bread + Butter","breakfast",250,6,30,12,"v"],["Tea / Milk","breakfast",100,4,12,4,"v"],
["Rice (1 plate)","lunch",260,5,57,1,"vg"],["Chapati (2)","lunch",200,6,38,3,"vg"],["Dal","lunch",150,8,20,4,"vg"],["Sambar","lunch",120,5,18,3,"vg"],["Aloo Curry","lunch",180,3,22,9,"vg"],["Mixed Veg Curry","lunch",120,3,14,6,"vg"],["Curd (small cup)","lunch",60,3,5,3,"v"],["Rajma Curry","lunch",200,9,30,4,"vg"],["Egg Curry (2 eggs)","lunch",220,13,5,16,"n"],
["Chapati (2) ","dinner",200,6,38,3,"vg"],["Rice (1 plate) ","dinner",260,5,57,1,"vg"],["Dal Fry","dinner",160,8,20,5,"vg"],["Paneer Curry","dinner",300,12,8,24,"v"],["Veg Curry","dinner",120,3,14,6,"vg"],["Chicken Curry","dinner",280,25,4,18,"n"],["Khichdi","dinner",300,10,52,6,"vg"]];
// cheap outside supplements: [name, cost, kcal, protein, diet]
const SUPP=[["2 Boiled Eggs",14,150,12,"n"],["Roasted Chana (50g)",8,185,10,"vg"],["Roasted Peanuts (50g)",6,285,13,"vg"],["Soya Chunks (30g dry)",6,100,16,"vg"],["Milk (250ml)",14,150,8,"v"],["Banana",5,105,1,"vg"],["Sattu Drink",8,150,10,"vg"],["Curd (100g)",8,60,4,"v"],["Peanut Butter (2 tbsp)",8,190,8,"vg"],["Bread (2 slices)",4,150,5,"vg"]];
const SEED_COMMUNITY=[
{title:"Hostel Kettle Egg Bhurji",author:"Hostel student, ECE",cost:18,protein:14,tip:"Boil, peel and mash 2 eggs in the kettle, then add chilli, salt and onion. No stove needed.",votes:9},
{title:"Soya Chunk Roast Box",author:"Hostel student, CSE",cost:10,protein:20,tip:"Soak 30g of soya, squeeze dry, dry roast with chilli powder. A protein snack that lasts 3 days.",votes:7},
{title:"Overnight Peanut Oats",author:"Hostel student, Mech",cost:24,protein:15,tip:"Soak oats in milk overnight, add a spoon of peanut butter and a banana. Zero cooking.",votes:5},
{title:"Curd Rice Power Bowl",author:"Hostel student, AIML",cost:20,protein:14,tip:"Leftover rice + curd + roasted peanuts + pickle. Cooling, filling and costs about 20 rupees.",votes:3}];

// lets server.js reuse this same file (the browser ignores this line)
if (typeof module !== "undefined") {
  module.exports = { R, MESS, SUPP, SEED_COMMUNITY, catOf };
}
