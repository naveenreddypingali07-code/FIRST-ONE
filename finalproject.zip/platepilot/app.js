
/* All the logic is in this file. Recipe data comes from data.js */

// ---------------------------------------------------------------
// Constants and shared state
// ---------------------------------------------------------------
const MEAL_SLOTS = ["breakfast", "lunch", "snack", "dinner"];
const SLOT_ICONS = { breakfast: "🌅", lunch: "🍛", snack: "🥜", dinner: "🌙" };
const WEEK_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const PANTRY_ITEMS = ["rice", "atta", "eggs", "dal", "oats", "peanuts", "milk", "banana", "potato", "bread", "onion"];

// words that tell me which protein source a meal is built on (used for the variety rule)
const PROTEIN_WORDS = /egg|chicken|paneer|soya|dal|rajma|chickpea|chole|chana|sprout|peanut|oats/i;

// everything the app remembers while it is open
const state = {
  profile: null,        // what the student typed in the form
  targets: null,        // calories and macros the student needs
  plan: null,           // today's 4 meals
  week: null,           // 7 days of plans
  pantry: new Set(),    // pantry items the student already owns
  swapCount: {},        // how many times each slot was swapped (to rotate suggestions)
  boughtItems: {}       // grocery items that are ticked
};

// short DOM helpers
function getElement(selector) {
  return document.querySelector(selector);
}
function getElements(selector) {
  return Array.from(document.querySelectorAll(selector));
}

function formatRupees(amount) {
  return "₹" + Math.round(amount);
}

function showToast(message) {
  const toast = getElement("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(function () {
    toast.classList.remove("show");
  }, 3200);
}

// ---------------------------------------------------------------
// Step 1: read the form and work out nutrition targets
// ---------------------------------------------------------------
function readProfile() {
  return {
    budget: Number(getElement("#budget").value),
    diet: getElement("#diet").value,
    goal: getElement("#goal").value,
    activity: Number(getElement("#act").value),
    age: Number(getElement("#age").value),
    sex: getElement("#sex").value,
    weight: Number(getElement("#w").value),
    height: Number(getElement("#h").value),
    priceFactor: 1 + Number(getElement("#adj").value) / 100,
    pantry: Array.from(state.pantry)
  };
}

// Mifflin-St Jeor formula for calories, then adjust for the goal
function calculateTargets(profile) {
  const sexConstant = profile.sex === "m" ? 5 : -161;
  const bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age + sexConstant;

  const goalCalorieChange = { gain: 150, maintain: 0, loss: -350 };
  const proteinPerKg = { gain: 1.6, maintain: 1.1, loss: 1.4 };

  const rawCalories = bmr * profile.activity + goalCalorieChange[profile.goal];
  const calories = Math.round(rawCalories / 50) * 50;
  const protein = Math.round(profile.weight * proteinPerKg[profile.goal]);
  const fat = Math.round((calories * 0.25) / 9);                      // 25% of calories from fat
  const carbs = Math.round((calories - protein * 4 - fat * 9) / 4);   // the rest from carbs

  return { kcal: calories, protein: protein, fat: fat, carbs: carbs };
}

// ---------------------------------------------------------------
// Step 2: recipes, prices and portions
// ---------------------------------------------------------------
function recipesForDiet(profile) {
  let allowedDiets;
  if (profile.diet === "n") {
    allowedDiets = ["vg", "v", "n"];
  } else if (profile.diet === "v") {
    allowedDiets = ["vg", "v"];
  } else {
    allowedDiets = ["vg"];
  }
  return R.filter(function (recipe) {
    return allowedDiets.includes(recipe.diet);
  });
}

// cost of one serving; pantry items cost nothing
function servingCost(recipe, profile) {
  let total = 0;
  recipe.ings.forEach(function (ingredient) {
    const name = ingredient[0].toLowerCase();
    const price = ingredient[1];
    const inPantry = profile.pantry.some(function (item) {
      return name.includes(item);
    });
    if (!inPantry) {
      total += price * profile.priceFactor;
    }
  });
  return total;
}

// make a meal object for a given portion size (1 = normal serving)
function makeMeal(recipeId, portion, profile) {
  const recipe = R[recipeId];
  return {
    id: recipeId,
    slot: recipe.slot,
    name: recipe.name,
    portion: portion,
    kcal: Math.round(recipe.kcal * portion),
    protein: Math.round(recipe.protein * portion),
    carbs: Math.round(recipe.carbs * portion),
    fat: Math.round(recipe.fat * portion),
    cost: servingCost(recipe, profile) * portion
  };
}

function proteinSource(mealName) {
  const match = mealName.match(PROTEIN_WORDS);
  return match ? match[0].toLowerCase() : "none";
}

function sumMeals(meals) {
  const totals = { kcal: 0, protein: 0, carbs: 0, fat: 0, cost: 0 };
  meals.forEach(function (meal) {
    totals.kcal += meal.kcal;
    totals.protein += meal.protein;
    totals.carbs += meal.carbs;
    totals.fat += meal.fat;
    totals.cost += meal.cost;
  });
  return totals;
}

// ---------------------------------------------------------------
// Step 3: score a full day (higher is better)
// ---------------------------------------------------------------
function scorePlan(meals, targets) {
  const totals = sumMeals(meals);

  const calorieGapPercent = (Math.abs(totals.kcal - targets.kcal) / targets.kcal) * 100;
  const proteinShortage = Math.max(0, targets.protein - totals.protein);
  const proteinShortagePercent = (proteinShortage / targets.protein) * 100;
  const proteinPerRupee = totals.protein / Math.max(totals.cost, 1);

  // same protein source twice in one day is boring, so it loses points
  let varietyPenalty = 0;
  const seenSources = {};
  meals.forEach(function (meal) {
    const source = proteinSource(meal.name);
    if (source !== "none") {
      if (seenSources[source]) {
        varietyPenalty += 12;
      }
      seenSources[source] = true;
    }
  });

  return -calorieGapPercent - proteinShortagePercent * 1.5 + proteinPerRupee * 3 - varietyPenalty;
}

// ---------------------------------------------------------------
// Step 4: knapsack-style optimizer
// Try every breakfast + lunch + snack + dinner combination that fits the budget,
// then buy bigger portions with any money that is left.
// ---------------------------------------------------------------
function generatePlan(profile, targets, mealsToAvoid) {
  mealsToAvoid = mealsToAvoid || [];
  const diets = recipesForDiet(profile);

  // one list of candidate meals per slot
  const optionsPerSlot = MEAL_SLOTS.map(function (slot) {
    let recipes = diets.filter(function (r) {
      return r.slot === slot && !mealsToAvoid.includes(r.id);
    });
    if (recipes.length === 0) {
      recipes = diets.filter(function (r) {
        return r.slot === slot;
      });
    }
    return recipes.map(function (r) {
      return makeMeal(r.id, 1, profile);
    });
  });

  const breakfasts = optionsPerSlot[0];
  const lunches = optionsPerSlot[1];
  const snacks = optionsPerSlot[2];
  const dinners = optionsPerSlot[3];

  // collect every combination that stays inside the budget
  const candidates = [];
  breakfasts.forEach(function (breakfast) {
    lunches.forEach(function (lunch) {
      const costSoFar = breakfast.cost + lunch.cost;
      if (costSoFar > profile.budget) return;

      snacks.forEach(function (snack) {
        const costWithSnack = costSoFar + snack.cost;
        if (costWithSnack > profile.budget) return;

        dinners.forEach(function (dinner) {
          if (costWithSnack + dinner.cost > profile.budget) return;
          const combo = [breakfast, lunch, snack, dinner];
          // small random number so "New variation" gives a different plan
          candidates.push({ meals: combo, score: scorePlan(combo, targets) + Math.random() * 3 });
        });
      });
    });
  });

  candidates.sort(function (a, b) {
    return b.score - a.score;
  });

  // bigger portions can change which combo is best, so upgrade the top 150 and compare again
  let bestPlan = null;
  let bestScore = -Infinity;
  candidates.slice(0, 150).forEach(function (candidate) {
    const upgraded = upgradePortions(candidate.meals.slice(), profile, targets);
    const score = scorePlan(upgraded, targets);
    if (score > bestScore) {
      bestScore = score;
      bestPlan = upgraded;
    }
  });

  // budget too low: fall back to the cheapest meal in each slot and mark the plan as over budget
  let overBudget = false;
  if (bestPlan === null) {
    bestPlan = optionsPerSlot.map(function (options) {
      return options.slice().sort(function (a, b) {
        return a.cost - b.cost;
      })[0];
    });
    overBudget = true;
  }
  bestPlan.over = overBudget || sumMeals(bestPlan).cost > profile.budget + 0.01;
  return bestPlan;
}

// spend leftover rupees on bigger portions (max 1.75x), one step at a time
function upgradePortions(plan, profile, targets) {
  let improved = true;
  while (improved) {
    improved = false;
    let bestScore = scorePlan(plan, targets);
    let bestIndex = -1;
    let bestPortion = 1;

    plan.forEach(function (meal, index) {
      const biggerPortion = Number((meal.portion + 0.25).toFixed(2));
      if (biggerPortion > 1.75) return;

      const trial = plan.slice();
      trial[index] = makeMeal(meal.id, biggerPortion, profile);
      if (sumMeals(trial).cost > profile.budget) return;

      const trialScore = scorePlan(trial, targets);
      if (trialScore > bestScore + 0.01) {
        bestScore = trialScore;
        bestIndex = index;
        bestPortion = biggerPortion;
      }
    });

    if (bestIndex >= 0) {
      plan[bestIndex] = makeMeal(plan[bestIndex].id, bestPortion, profile);
      improved = true;
    }
  }
  return plan;
}

// out of 100: 45 for calories, 45 for protein, 10 for variety
function nutritionScore(plan, targets) {
  const totals = sumMeals(plan);
  const calorieMatch = Math.max(0, 1 - (Math.abs(totals.kcal - targets.kcal) / targets.kcal) * 3);
  const proteinMatch = Math.min(1, totals.protein / targets.protein);

  const sources = plan.map(function (m) {
    return proteinSource(m.name);
  }).filter(function (s) {
    return s !== "none";
  });
  const allDifferent = new Set(sources).size === sources.length;
  const varietyPoints = allDifferent ? 10 : 5;

  return Math.round(45 * calorieMatch + 45 * proteinMatch + varietyPoints);
}

// ---------------------------------------------------------------
// Daily plan screen
// ---------------------------------------------------------------
const chartInstances = {};

function renderPlan() {
  const plan = state.plan;
  const profile = state.profile;
  const targets = state.targets;
  const totals = sumMeals(plan);
  const moneyLeft = profile.budget - totals.cost;

  getElement("#out").hidden = false;
  getElement("#emptyPlan").hidden = true;

  // stat cards
  const stats = [
    { cls: "hl", value: formatRupees(totals.cost), label: "spent of " + formatRupees(profile.budget) },
    { cls: "", value: totals.kcal, label: "kcal (target " + targets.kcal + ")" },
    { cls: "", value: totals.protein + " g", label: "protein (target " + targets.protein + " g)" },
    { cls: "", value: (totals.protein / Math.max(totals.cost, 1)).toFixed(2) + " g", label: "protein per rupee" },
    { cls: "", value: nutritionScore(plan, targets) + "/100", label: "nutrition score" }
  ];
  getElement("#stats").innerHTML = stats.map(function (stat) {
    return '<div class="stat ' + stat.cls + '"><b>' + stat.value + "</b><span>" + stat.label + "</span></div>";
  }).join("");

  // budget meter
  getElement("#bar").style.width = Math.min(100, (totals.cost / profile.budget) * 100) + "%";
  getElement("#bar").style.background = plan.over ? "#d94b4b" : "";
  if (plan.over) {
    getElement("#meterTxt").textContent = "Over budget by " + formatRupees(-moneyLeft);
  } else {
    getElement("#meterTxt").textContent = formatRupees(moneyLeft) + " left in today's budget";
  }

  getElement("#notice").innerHTML = buildNotice(plan, totals, targets, profile);
  getElement("#meals").innerHTML = plan.map(function (meal, index) {
    return buildMealCard(meal, index, profile);
  }).join("");

  const sexText = profile.sex === "m" ? "male" : "female";
  getElement("#targetTxt").textContent =
    "Targets for a " + profile.age + "-year-old " + sexText + ", " + profile.weight + " kg, " + profile.height + " cm: " +
    targets.kcal + " kcal, " + targets.protein + " g protein, " + targets.carbs + " g carbs, " + targets.fat + " g fat.";

  drawDoughnut("c1", [totals.protein, totals.carbs, totals.fat]);
  drawDoughnut("c2", [targets.protein, targets.carbs, targets.fat]);

  getElement("#bars").innerHTML =
    progressBar("Calories", totals.kcal, targets.kcal, "") +
    progressBar("Protein", totals.protein, targets.protein, "g") +
    progressBar("Carbs", totals.carbs, targets.carbs, "g") +
    progressBar("Fats", totals.fat, targets.fat, "g");

  savePlan();
}

function buildNotice(plan, totals, targets) {
  if (plan.over) {
    return '<div class="notice bad">Your budget is too low for a full 4-meal plan with these preferences. ' +
      "The cheapest possible plan costs " + formatRupees(totals.cost) + ". Increase the budget or use the pantry options.</div>";
  }
  if (totals.protein < targets.protein * 0.9) {
    return '<div class="notice">Protein is ' + (targets.protein - totals.protein) +
      " g below target at this budget. Try adding ₹10, or choose a soya-heavy vegetarian or vegan plan.</div>";
  }
  return "";
}

function buildMealCard(meal, index, profile) {
  const recipe = R[meal.id];
  const portionText = meal.portion !== 1 ? meal.portion + "× portion" : "1 serving";

  const ingredientLines = recipe.ings.map(function (ingredient) {
    const price = ingredient[1] * profile.priceFactor * meal.portion;
    return "<li>" + ingredient[0] + " " + formatRupees(price) + "</li>";
  }).join("");

  return '<div class="meal" id="meal' + index + '">' +
    '<span class="slot">' + SLOT_ICONS[meal.slot] + " " + meal.slot + "</span>" +
    "<h4>" + meal.name + "</h4>" +
    '<div><span class="badge">' + formatRupees(meal.cost) + '</span> <span class="tag">' + portionText +
    '</span><span class="tag">⏱ ' + recipe.prep + " min</span></div>" +
    '<div class="macros">' + meal.kcal + " kcal · P " + meal.protein + "g · C " + meal.carbs + "g · F " + meal.fat + "g</div>" +
    "<ul>" + ingredientLines + "</ul>" +
    '<div class="how"><b>How:</b> ' + recipe.steps + "</div>" +
    '<button class="btn ghost" onclick="swapMeal(' + index + ')">⇄ Swap ' + meal.slot + "</button></div>";
}

function progressBar(label, value, target, unit) {
  const percent = Math.round((value / target) * 100);
  const colourClass = percent > 115 ? "o" : "";
  return '<div class="pb"><div><span>' + label + "</span><span>" + value + unit + " / " + target + unit + " (" + percent + '%)</span></div>' +
    '<div class="t"><i class="' + colourClass + '" style="width:' + Math.min(100, percent) + '%"></i></div></div>';
}

function drawDoughnut(canvasId, values) {
  if (typeof Chart === "undefined") return;   // chart library missing, skip drawing
  if (chartInstances[canvasId]) {
    chartInstances[canvasId].destroy();
  }
  chartInstances[canvasId] = new Chart(getElement("#" + canvasId), {
    type: "doughnut",
    data: {
      labels: ["Protein", "Carbs", "Fats"],
      datasets: [{ data: values, backgroundColor: ["#16a06a", "#ff8a3d", "#e85d75"], borderWidth: 2 }]
    },
    options: { cutout: "62%", plugins: { legend: { position: "bottom" } } }
  });
}

// ---------------------------------------------------------------
// Swap button: find another meal for the same slot that fits the remaining budget
// ---------------------------------------------------------------
function swapMeal(index) {
  const profile = state.profile;
  const targets = state.targets;
  const currentMeal = state.plan[index];
  const currentTotals = sumMeals(state.plan);
  const moneyAvailable = profile.budget - (currentTotals.cost - currentMeal.cost);
  const idsAlreadyUsed = state.plan.map(function (m) {
    return m.id;
  });

  const alternatives = [];
  recipesForDiet(profile).forEach(function (recipe) {
    if (recipe.slot !== currentMeal.slot || idsAlreadyUsed.includes(recipe.id)) return;

    // try three portion sizes and keep the one that gives the best day
    let bestOption = null;
    [1, 1.25, 1.5].forEach(function (portion) {
      const meal = makeMeal(recipe.id, portion, profile);
      if (meal.cost > moneyAvailable + 0.001) return;
      const trialPlan = state.plan.slice();
      trialPlan[index] = meal;
      const score = scorePlan(trialPlan, targets);
      if (bestOption === null || score > bestOption.score) {
        bestOption = { meal: meal, score: score };
      }
    });
    if (bestOption !== null) {
      alternatives.push(bestOption);
    }
  });

  if (alternatives.length === 0) {
    showToast("No other " + currentMeal.slot + " option fits your remaining budget.");
    return;
  }

  alternatives.sort(function (a, b) {
    return b.score - a.score;
  });

  // rotate through the best few so clicking swap again gives a new dish
  const timesSwapped = state.swapCount[currentMeal.slot] || 0;
  state.swapCount[currentMeal.slot] = timesSwapped + 1;
  const newMeal = alternatives[timesSwapped % Math.min(alternatives.length, 6)].meal;

  const costChange = Math.round(newMeal.cost - currentMeal.cost);
  const kcalChange = newMeal.kcal - currentMeal.kcal;

  state.plan[index] = newMeal;
  state.plan.over = false;
  state.week = null;
  renderPlan();

  getElement("#meal" + index).classList.add("flash");
  const costText = (costChange >= 0 ? "+" : "-") + "₹" + Math.abs(costChange);
  const kcalText = (kcalChange >= 0 ? "+" : "") + kcalChange;
  showToast("Swapped to " + newMeal.name + ": " + costText + ", " + kcalText + " kcal. Cost meter updated.");
}

// ---------------------------------------------------------------
// 7 day plan and grocery list (never repeat yesterday's meals)
// ---------------------------------------------------------------
function buildWeek() {
  if (!state.plan) return;
  let yesterdayIds = [];
  state.week = [];
  for (let day = 0; day < 7; day++) {
    const dayPlan = generatePlan(state.profile, state.targets, yesterdayIds);
    state.week.push(dayPlan);
    yesterdayIds = dayPlan.map(function (m) {
      return m.id;
    });
  }
  state.boughtItems = {};
}

// add up every ingredient for the week, then group by category
function buildGroceryList() {
  const items = {};
  state.week.forEach(function (dayPlan) {
    dayPlan.forEach(function (meal) {
      R[meal.id].ings.forEach(function (ingredient) {
        const name = ingredient[0];
        const inPantry = state.profile.pantry.some(function (p) {
          return name.toLowerCase().includes(p);
        });
        const price = inPantry ? 0 : ingredient[1];
        if (!items[name]) {
          items[name] = { servings: 0, cost: 0 };
        }
        items[name].servings += meal.portion;
        items[name].cost += price * state.profile.priceFactor * meal.portion * 0.9;   // 10% bulk discount
      });
    });
  });

  const categories = {};
  Object.keys(items).forEach(function (name) {
    const category = catOf(name);
    if (!categories[category]) {
      categories[category] = [];
    }
    categories[category].push([name, items[name]]);
  });
  return categories;
}

function renderWeek() {
  if (!state.plan) {
    getElement("#weekMsg").textContent = "Generate a daily plan first (Daily Plan tab).";
    getElement("#weekTbl").innerHTML = "";
    getElement("#groc").innerHTML = "";
    return;
  }
  if (!state.week) {
    buildWeek();
  }

  let weekCost = 0;
  state.week.forEach(function (dayPlan) {
    weekCost += sumMeals(dayPlan).cost;
  });
  getElement("#weekMsg").textContent = "Weekly food cost " + formatRupees(weekCost) + " (average " + formatRupees(weekCost / 7) +
    " per day, budget " + formatRupees(state.profile.budget) + "). No meal repeats on consecutive days.";

  let tableHtml = "<tr><th>Day</th>";
  MEAL_SLOTS.forEach(function (slot) {
    tableHtml += "<th>" + SLOT_ICONS[slot] + " " + slot + "</th>";
  });
  tableHtml += "<th>Kcal</th><th>Protein</th><th>Cost</th></tr>";

  state.week.forEach(function (dayPlan, dayIndex) {
    const totals = sumMeals(dayPlan);
    tableHtml += "<tr><td><b>" + WEEK_DAYS[dayIndex] + "</b></td>";
    dayPlan.forEach(function (meal) {
      tableHtml += "<td>" + meal.name + "<br><small>" + formatRupees(meal.cost) + "</small></td>";
    });
    tableHtml += "<td>" + totals.kcal + "</td><td>" + totals.protein + " g</td><td><b>" + formatRupees(totals.cost) + "</b></td></tr>";
  });
  getElement("#weekTbl").innerHTML = tableHtml;

  // grocery list
  const categories = buildGroceryList();
  let groceryHtml = "";
  let grandTotal = 0;
  Object.keys(categories).forEach(function (category) {
    groceryHtml += '<div class="cat">' + category + "</div><table>";
    categories[category].forEach(function (entry) {
      const name = entry[0];
      const info = entry[1];
      const key = category + name;
      const isBought = Boolean(state.boughtItems[key]);
      grandTotal += info.cost;
      groceryHtml += '<tr class="gi ' + (isBought ? "done" : "") + '"><td><input type="checkbox" ' + (isBought ? "checked" : "") +
        " onchange=\"tickItem('" + key.replace(/'/g, "\\'") + "', this.checked)\"></td><td>" + name + "</td><td>" +
        Number(info.servings.toFixed(1)) + " servings this week</td><td><b>≈ " + formatRupees(info.cost) + "</b></td></tr>";
    });
    groceryHtml += "</table>";
  });
  groceryHtml += '<div class="total">Estimated weekly grocery bill: ' + formatRupees(grandTotal) +
    " <small>(bulk prices, " + formatRupees(grandTotal / 7) + "/day)</small></div>";
  getElement("#groc").innerHTML = groceryHtml;

  savePlan();
}

function tickItem(key, isChecked) {
  state.boughtItems[key] = isChecked;
  renderWeek();
}

// ---------------------------------------------------------------
// Fridge cheat sheet: fills the hidden #sheet div, then opens the print dialog (save as PDF)
// ---------------------------------------------------------------
function printFridgeSheet() {
  if (!state.plan) {
    showToast("Generate a plan first.");
    return;
  }
  if (!state.week) {
    buildWeek();
  }

  let weekCost = 0;
  const recipesUsed = {};
  state.week.forEach(function (dayPlan) {
    weekCost += sumMeals(dayPlan).cost;
    dayPlan.forEach(function (meal) {
      recipesUsed[meal.id] = meal;
    });
  });

  const categories = buildGroceryList();
  let groceryHtml = "";
  let groceryTotal = 0;
  Object.keys(categories).forEach(function (category) {
    groceryHtml += "<b>" + category + "</b><br>";
    categories[category].forEach(function (entry) {
      groceryTotal += entry[1].cost;
      groceryHtml += "☐ " + entry[0] + " (" + Number(entry[1].servings.toFixed(1)) + "×) ≈ " + formatRupees(entry[1].cost) + "<br>";
    });
    groceryHtml += "<br>";
  });

  let rows = "";
  state.week.forEach(function (dayPlan, dayIndex) {
    rows += "<tr><td><b>" + WEEK_DAYS[dayIndex] + "</b></td>";
    dayPlan.forEach(function (meal) {
      rows += "<td>" + meal.name + " (" + formatRupees(meal.cost) + ")</td>";
    });
    rows += "<td>" + formatRupees(sumMeals(dayPlan).cost) + "</td></tr>";
  });

  const recipeBoxes = Object.keys(recipesUsed).map(function (id) {
    const recipe = R[id];
    const ingredientNames = recipe.ings.map(function (i) {
      return i[0];
    }).join(", ");
    return "<div><b>" + recipe.name + "</b> · " + recipe.prep + " min<br>" + ingredientNames + "<br><i>" + recipe.steps + "</i></div>";
  }).join("");

  const headings = MEAL_SLOTS.map(function (slot) {
    return "<th>" + slot + "</th>";
  }).join("");

  getElement("#sheet").innerHTML =
    "<h1>PlatePilot: 7-Day Meal Plan</h1>" +
    "<p>Budget " + formatRupees(state.profile.budget) + "/day · Target " + state.targets.kcal + " kcal, " + state.targets.protein +
    " g protein · Weekly food cost " + formatRupees(weekCost) + " · Grocery bill ≈ " + formatRupees(groceryTotal) + "</p>" +
    "<table><tr><th>Day</th>" + headings + "<th>Cost</th></tr>" + rows + "</table>" +
    '<h2>Recipes</h2><div class="rc">' + recipeBoxes + "</div>" +
    '<h2>Grocery list</h2><div class="gl">' + groceryHtml + "</div>";

  setTimeout(function () {
    window.print();
  }, 150);
}

// ---------------------------------------------------------------
// Hostel mess mode: student ticks mess food, I fill the protein/calorie gap
// with the cheapest outside items
// ---------------------------------------------------------------
function allowedDietsFor(dietCode) {
  if (dietCode === "n") return ["vg", "v", "n"];
  if (dietCode === "v") return ["vg", "v"];
  return ["vg"];
}

function renderMessMenu() {
  const profile = state.profile || readProfile();
  const allowed = allowedDietsFor(profile.diet);
  const tickedByDefault = ["Idli (3) + Sambar", "Rice (1 plate)", "Dal", "Mixed Veg Curry", "Chapati (2) ", "Dal Fry", "Veg Curry"];

  let html = "";
  ["breakfast", "lunch", "dinner"].forEach(function (mealName) {
    html += '<div class="messcol"><h4>' + SLOT_ICONS[mealName] + " " + mealName + "</h4>";
    MESS.forEach(function (item, itemIndex) {
      if (item[1] !== mealName || !allowed.includes(item[6])) return;
      const checked = tickedByDefault.includes(item[0]) ? "checked" : "";
      html += '<label><input type="checkbox" data-i="' + itemIndex + '" ' + checked + ">" + item[0] +
        "<span>" + item[2] + " kcal · " + item[3] + "g P</span></label>";
    });
    html += "</div>";
  });
  getElement("#messMenu").innerHTML = html;
}

function suggestSupplements() {
  const profile = readProfile();
  const targets = calculateTargets(profile);
  const chosenMess = getElements("#messMenu input:checked").map(function (box) {
    return MESS[Number(box.dataset.i)];
  });

  let kcal = 0;
  let protein = 0;
  chosenMess.forEach(function (item) {
    kcal += item[2];
    protein += item[3];
  });
  const messKcal = kcal;
  const messProtein = protein;

  const startingBudget = Number(getElement("#messBudget").value);
  let moneyLeft = startingBudget;
  const allowed = allowedDietsFor(profile.diet);
  const supplements = SUPP.filter(function (s) {
    return allowed.includes(s[4]);
  });
  const bought = {};

  // greedy: each round buy the item that fills the most gap per rupee (max 2 of each)
  for (let round = 0; round < 8; round++) {
    let bestItem = null;
    let bestValue = 0;
    supplements.forEach(function (item) {
      const timesBought = bought[item[0]] || 0;
      if (timesBought >= 2 || item[1] > moneyLeft) return;
      const usefulProtein = Math.max(0, Math.min(item[3], targets.protein - protein));
      const usefulKcal = Math.max(0, Math.min(item[2], targets.kcal - kcal));
      const valuePerRupee = (usefulProtein * 3 + usefulKcal / 50) / item[1];
      if (valuePerRupee > bestValue) {
        bestValue = valuePerRupee;
        bestItem = item;
      }
    });
    if (bestItem === null) break;
    bought[bestItem[0]] = (bought[bestItem[0]] || 0) + 1;
    moneyLeft -= bestItem[1];
    kcal += bestItem[2];
    protein += bestItem[3];
  }

  const moneySpent = startingBudget - moneyLeft;
  let tableRows = "";
  Object.keys(bought).forEach(function (name) {
    const item = SUPP.find(function (s) {
      return s[0] === name;
    });
    const qty = bought[name];
    tableRows += "<tr><td>" + name + (qty > 1 ? " × " + qty : "") + "</td><td>" + item[2] * qty + " kcal</td><td>" +
      item[3] * qty + " g</td><td>" + formatRupees(item[1] * qty) + "</td></tr>";
  });

  let html = '<div class="stats" style="margin-top:18px">' +
    '<div class="stat"><b>' + messKcal + "</b><span>mess kcal (target " + targets.kcal + ")</span></div>" +
    '<div class="stat"><b>' + messProtein + " g</b><span>mess protein (target " + targets.protein + " g)</span></div>" +
    '<div class="stat hl"><b>' + formatRupees(moneySpent) + "</b><span>outside supplements</span></div>" +
    '<div class="stat"><b>' + kcal + " / " + protein + " g</b><span>kcal / protein after</span></div></div>";

  if (tableRows) {
    html += "<h3>Buy these outside</h3><table><tr><th>Item</th><th>Calories</th><th>Protein</th><th>Cost</th></tr>" + tableRows + "</table>";
  } else {
    html += '<div class="notice">Your mess picks already meet your targets, or no supplement fits the extra budget.</div>';
  }
  html += '<p class="sub">Tip: supplements are chosen by protein and calories gained per rupee, so cheap staples like roasted chana, peanuts and soya come first.</p>';
  getElement("#messOut").innerHTML = html;
}

// ---------------------------------------------------------------
// Community board: recipes are saved in localStorage so no server is needed
// ---------------------------------------------------------------
function loadCommunityPosts() {
  try {
    const saved = JSON.parse(localStorage.getItem("pp_com"));
    if (saved) return saved;
  } catch (error) {
    // ignore and fall through to the sample posts
  }
  return SEED_COMMUNITY.map(function (post) {
    return Object.assign({}, post);
  });
}

let communityPosts = loadCommunityPosts();

function renderCommunity() {
  communityPosts.sort(function (a, b) {
    return b.votes - a.votes;
  });
  getElement("#comList").innerHTML = communityPosts.map(function (post, index) {
    const verified = post.votes >= 5 ? '<span class="ver">✔ Verified cost</span>' : "";
    return '<div class="meal"><h4>' + post.title + '</h4><div><span class="badge">' + formatRupees(post.cost) +
      '</span> <span class="tag">' + post.protein + " g protein</span> " + verified + "</div>" +
      '<div class="how" style="border:0;padding:0">' + post.tip + "</div>" +
      '<div class="macros">by ' + (post.author || "Anonymous") + "</div>" +
      '<button class="vote" onclick="upvotePost(' + index + ')">▲ ' + post.votes + " Upvote</button></div>";
  }).join("");
}

function upvotePost(index) {
  communityPosts[index].votes++;
  localStorage.setItem("pp_com", JSON.stringify(communityPosts));
  renderCommunity();
}

// ---------------------------------------------------------------
// Save and restore the last plan so it is still there after a refresh
// ---------------------------------------------------------------
function savePlan() {
  try {
    localStorage.setItem("platepilot", JSON.stringify({
      plan: state.plan,
      profile: state.profile,
      targets: state.targets,
      week: state.week,
      form: { budget: getElement("#budget").value, diet: getElement("#diet").value, goal: getElement("#goal").value }
    }));
  } catch (error) {
    // storage full or blocked: the app still works, it just won't remember
  }
}

function restorePlan() {
  try {
    const saved = JSON.parse(localStorage.getItem("platepilot"));
    if (!saved || !saved.plan) return;
    state.plan = saved.plan;
    state.profile = saved.profile;
    state.targets = saved.targets;
    state.week = saved.week;
    state.plan.over = false;
    getElement("#budget").value = saved.form.budget;
    getElement("#diet").value = saved.form.diet;
    getElement("#goal").value = saved.form.goal;
    renderPlan();
  } catch (error) {
    // old or broken saved data: start fresh
  }
}

// ---------------------------------------------------------------
// Button handlers
// ---------------------------------------------------------------
function onGenerate(event) {
  if (event) event.preventDefault();
  const profile = readProfile();
  if (profile.budget < 40) {
    showToast("Please enter a budget of at least ₹40.");
    return;
  }
  state.profile = profile;
  state.targets = calculateTargets(profile);
  state.plan = generatePlan(profile, state.targets);
  state.week = null;
  state.swapCount = {};
  renderPlan();

  const totals = sumMeals(state.plan);
  if (!state.plan.over) {
    showToast("Plan ready: " + formatRupees(totals.cost) + " for " + totals.kcal + " kcal and " + totals.protein + " g protein.");
  }
  getElement("#out").scrollIntoView({ behavior: "smooth", block: "start" });
}

function showView(viewName) {
  getElements(".view").forEach(function (section) {
    section.classList.toggle("active", section.id === "view-" + viewName);
  });
  getElements("#tabs button").forEach(function (button) {
    button.classList.toggle("active", button.dataset.view === viewName);
  });
  if (viewName === "week") renderWeek();
  if (viewName === "mess") renderMessMenu();
  if (viewName === "community") renderCommunity();
  window.scrollTo({ top: viewName === "plan" ? 0 : 150, behavior: "smooth" });
}

function runDemo() {
  // the demo from the hackathon brief: 120 rupees, high protein
  getElement("#budget").value = 120;
  getElement("#diet").value = "n";
  getElement("#goal").value = "gain";
  getElement("#act").value = "1.375";
  getElement("#age").value = 20;
  getElement("#sex").value = "m";
  getElement("#w").value = 60;
  getElement("#h").value = 170;
  getElement("#adj").value = 0;
  getElement("#pv").textContent = "0%";
  state.pantry.clear();
  getElements("#pantryChips button").forEach(function (chip) {
    chip.classList.remove("on");
  });
  showView("plan");
  onGenerate();
}

/* ---- wiring (event listeners) ---- */
getElement("#form").onsubmit = onGenerate;
getElement("#regen").onclick = function () { onGenerate(); };
getElement("#toWeek").onclick = function () { showView("week"); };
getElement("#reWeek").onclick = function () { state.week = null; renderWeek(); };
getElement("#printBtn").onclick = printFridgeSheet;
getElement("#printBtn2").onclick = printFridgeSheet;
getElement("#demoBtn").onclick = runDemo;
getElement("#messBtn").onclick = suggestSupplements;

getElement("#adj").oninput = function () {
  const value = getElement("#adj").value;
  getElement("#pv").textContent = (value > 0 ? "+" : "") + value + "%";
};

getElements("#tabs button").forEach(function (button) {
  button.onclick = function () { showView(button.dataset.view); };
});

getElement("#budgetChips").onclick = function (event) {
  if (event.target.dataset.b) {
    getElement("#budget").value = event.target.dataset.b;
  }
};

getElement("#pantryChips").innerHTML = PANTRY_ITEMS.map(function (item) {
  return '<button type="button" data-p="' + item + '">' + item + "</button>";
}).join("");

getElement("#pantryChips").onclick = function (event) {
  const item = event.target.dataset.p;
  if (!item) return;
  if (state.pantry.has(item)) {
    state.pantry.delete(item);
  } else {
    state.pantry.add(item);
  }
  event.target.classList.toggle("on");
};

getElement("#comForm").onsubmit = function (event) {
  event.preventDefault();
  communityPosts.push({
    title: getElement("#cTitle").value.trim(),
    cost: Number(getElement("#cCost").value),
    protein: Number(getElement("#cProt").value),
    author: getElement("#cAuth").value.trim(),
    tip: getElement("#cTip").value.trim(),
    votes: 0
  });
  localStorage.setItem("pp_com", JSON.stringify(communityPosts));
  event.target.reset();
  renderCommunity();
  showToast("Recipe shared. Get 5 upvotes for the Verified badge.");
};

restorePlan();
