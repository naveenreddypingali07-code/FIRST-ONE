# PlatePilot - Eat Well. Spend Less.

**Made by:** P Naveen Reddy (26MVCSMR0332) ,P.HARSHA (26MVCSMR0333),P.AKSHAY(26MVCSMR0331) AIML-D, Malla Reddy Vishwavidyapeeth - Technical Campus


## The problem
Hostel students on a tight budget often live on instant noodles and fast food. Normal nutrition apps assume expensive ingredients and a full kitchen. PlatePilot makes a balanced day of meals for ₹100 to ₹150.

## What it does
- Profile: daily budget, veg / non-veg / vegan, goal, age, weight, height, activity
- Works out calorie, protein, carb and fat targets
- Knapsack-style optimizer for breakfast, lunch, snack and dinner that never goes over the budget
- Doughnut charts of macros against targets
- Cost and recipe breakdown for every meal
- One-click meal swap, 7-day plan, categorised grocery list
- Printable fridge sheet (print > save as PDF)
- Stretch features: Hostel Mess Mode, pantry optimizer, community recipe board

## How to run
Just open `index.html` in Chrome or Edge. No install needed.
Optional backend: `npm install` then `npm start` and open http://localhost:3000

## Demo
Click "Run the ₹120 High-Protein Demo". Sample result: about 2,300 kcal and 125 g protein for ₹115.

## Files
- index.html, style.css, app.js - the web app
- data.js - 50 recipes, mess menu, supplements, sample community posts
- server.js - optional Express server

## Notes
Prices and nutrition values are approximate estimates, not medical advice. 
