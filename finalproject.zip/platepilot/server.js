// Optional backend. Run: npm install, then npm start, then open http://localhost:3000
const express = require("express");
const { R } = require("./data.js");

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

// GET /api/recipes?diet=v&slot=lunch&q=dal
app.get("/api/recipes", function (req, res) {
  const { diet, slot, q } = req.query;
  const results = R.filter(function (recipe) {
    const dietOk = !diet || recipe.diet === diet;
    const slotOk = !slot || recipe.slot === slot;
    const nameOk = !q || recipe.name.toLowerCase().includes(q.toLowerCase());
    return dietOk && slotOk && nameOk;
  });
  res.json(results);
});

app.listen(3000, function () {
  console.log("PlatePilot running on http://localhost:3000");
});
