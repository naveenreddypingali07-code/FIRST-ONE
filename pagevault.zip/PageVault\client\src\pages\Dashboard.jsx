import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context';
import ChatPanel from '../components/ChatPanel';
import { Countdown, Cover, Empty, Stars, StatusBadge } from '../components/ui';
import { fmtDate } from '../utils';

function Row({ cover, children, side }) {
  return (
    <div className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center">
      <div className="flex flex-1 items-center gap-3">
        <div className="h-20 w-16 shrink-0 overflow-hidden rounded-lg shadow">{cover}</div>
        <div className="min-w-0 flex-1">{children}</div>
      </div>
      <div className="flex flex-wrap items-center gap-2 sm:w-72 sm:justify-end">{side}</div>
    </div>
  );
}

export default function Dashboard() {
  const { user, tick, refresh, toast } = useApp();
  const [books, setBooks] = useState([]);
  const [reqs, setReqs] = useState([]);
  const [tab, setTab] = useState('borrowed');
  const [chat, setChat] = useState(null);
  const [loaded, setLoaded] = useState(false);

  const load = () => Promise.all([api.get('/books'), api.get('/requests')]).then(([b, r]) => { setBooks(b.filter((x) => x.ownerId === user.id)); setReqs(r); setLoaded(true); });
  useEffect(() => { load(); }, [tick, user.id]);
  const act = async (id, action, msg) => {
    try { await api.patch('/requests/' + id, { action }); toast(msg, 'success'); refresh(); load(); } catch (e) { toast(e.message, 'error'); load(); }
  };
  const simulate = async (id, daysLeft) => { try { await api.post('/requests/' + id + '/simulate', { daysLeft }); toast('Due date moved (demo)', 'info'); load(); refresh(); } catch (e) { toast(e.message, 'error'); } };
  const rate = async (id, rating) => { try { await api.post('/reviews', { requestId: id, rating }); toast('Thanks for rating!', 'success'); load(); } catch (e) { toast(e.message, 'error'); } };
  const toggle = async (b) => { try { await api.patch('/books/' + b.id, { available: !b.available }); load(); refresh(); } catch (e) { toast(e.message, 'error'); } };
  const remove = async (b) => { if (!confirm('Remove "' + b.title + '" from PageVault?')) return; try { await api.del('/books/' + b.id); toast('Book removed', 'success'); load(); } catch (e) { toast(e.message, 'error'); } };

  const borrowing = reqs.filter((r) => r.borrowerId === user.id && r.status === 'Approved');
  const requested = reqs.filter((r) => r.borrowerId === user.id && r.status === 'Pending');
  const incoming = reqs.filter((r) => r.lenderId === user.id && r.status === 'Pending');
  const lentOut = reqs.filter((r) => r.lenderId === user.id && r.status === 'Approved');
  const history = reqs.filter((r) => ['Returned', 'Rejected', 'Cancelled'].includes(r.status));
  const tabs = [['borrowed', 'Borrowed by me', borrowing.length + requested.length], ['requests', 'Incoming requests', incoming.length], ['lent', 'Lent out', lentOut.length], ['books', 'My listed books', books.length], ['history', 'History', history.length]];
  const who = (r) => (r.lenderId === user.id ? r.borrower : r.lender);

  return (
    <div>
      <h1 className="text-2xl font-extrabold">My Exchanges</h1>
      <p className="text-sm text-slate-500">Hi {user.name.split(' ')[0]}! Everything you lend and borrow, in one place.</p>
      <div className="mt-4 flex gap-1 overflow-x-auto border-b border-slate-200" role="tablist">
        {tabs.map(([k, label, n]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={'whitespace-nowrap border-b-2 px-4 py-2 text-sm font-semibold ' + (tab === k ? 'border-vault-600 text-vault-700' : 'border-transparent text-slate-500 hover:text-slate-800')}>
            {label} <span className={'ml-1 rounded-full px-1.5 text-xs ' + (k === 'requests' && n ? 'bg-rose-500 text-white' : 'bg-slate-200')}>{n}</span>
          </button>
        ))}
      </div>
      <div className="mt-4 space-y-3">
        {!loaded && <div className="card h-24 animate-pulse bg-slate-200" />}

        {loaded && tab === 'borrowed' && (<>
          {!borrowing.length && !requested.length && <Empty icon="📖" title="You have not borrowed anything yet" hint="Browse the catalog and request a book."><Link to="/" className="btn-primary">Browse books</Link></Empty>}
          {borrowing.map((r) => (
            <Row key={r.id} cover={<Cover book={r.book} className="h-full w-full" />}
              side={<><div className="w-full"><Countdown due={r.dueDate} /></div>
                <button className="btn-ghost !py-1" onClick={() => setChat(r)}>💬 Chat</button>
                <button className="btn-ghost !py-1 !text-xs" onClick={() => simulate(r.id, -1)} title="Demo helper">⏩ Simulate overdue</button></>}>
              <div className="flex items-center gap-2"><StatusBadge status="Borrowed" /><span className="text-xs font-bold text-slate-500">{r.book.courseCode}</span></div>
              <p className="truncate font-semibold">{r.book.title}</p>
              <p className="text-xs text-slate-500">From {r.lender.name} · due {fmtDate(r.dueDate)}</p>
            </Row>
          ))}
          {requested.map((r) => (
            <Row key={r.id} cover={<Cover book={r.book} className="h-full w-full" />}
              side={<><button className="btn-ghost !py-1" onClick={() => setChat(r)}>💬 Chat</button><button className="btn-ghost !py-1" onClick={() => act(r.id, 'cancel', 'Request cancelled')}>Cancel request</button></>}>
              <div className="flex items-center gap-2"><StatusBadge status="Pending" /><span className="text-xs font-bold text-slate-500">{r.book.courseCode}</span></div>
              <p className="truncate font-semibold">{r.book.title}</p><p className="text-xs text-slate-500">Waiting for {r.lender.name} to approve</p>
            </Row>
          ))}
        </>)}

        {loaded && tab === 'requests' && (<>
          {!incoming.length && <Empty icon="📬" title="No pending requests" hint="When a classmate asks to borrow one of your books, it appears here." />}
          {incoming.map((r) => (
            <Row key={r.id} cover={<Cover book={r.book} className="h-full w-full" />}
              side={<><button className="btn-ok !py-1.5" onClick={() => act(r.id, 'approve', 'Approved. The 7-day clock has started.')}>Approve</button><button className="btn-danger !py-1.5" onClick={() => act(r.id, 'reject', 'Request declined')}>Reject</button><button className="btn-ghost !py-1.5" onClick={() => setChat(r)}>💬</button></>}>
              <StatusBadge status="Pending" /><p className="truncate font-semibold">{r.book.title}</p>
              <p className="text-xs text-slate-500">{r.borrower.name} · {r.borrower.department} · reliability {r.borrower.trust.count ? r.borrower.trust.average + '★' : 'new'}</p>
            </Row>
          ))}
        </>)}

        {loaded && tab === 'lent' && (<>
          {!lentOut.length && <Empty icon="🤝" title="Nothing lent out right now" />}
          {lentOut.map((r) => (
            <Row key={r.id} cover={<Cover book={r.book} className="h-full w-full" />}
              side={<><div className="w-full"><Countdown due={r.dueDate} /></div>
                <button className="btn-ok !py-1" onClick={() => act(r.id, 'return', 'Marked as returned')}>Mark returned</button>
                <button className="btn-ghost !py-1" onClick={() => act(r.id, 'extend', 'Extended by 3 days')}>+3 days</button>
                <button className="btn-ghost !py-1" onClick={() => setChat(r)}>💬</button></>}>
              <StatusBadge status="Borrowed" /><p className="truncate font-semibold">{r.book.title}</p><p className="text-xs text-slate-500">With {r.borrower.name} · due {fmtDate(r.dueDate)}</p>
            </Row>
          ))}
        </>)}

        {loaded && tab === 'books' && (<>
          {!books.length && <Empty icon="📚" title="You have not listed any books" hint="Share textbooks you are done with."><Link to="/list" className="btn-primary">List a book</Link></Empty>}
          {books.map((b) => (
            <Row key={b.id} cover={<Cover book={b} className="h-full w-full" />}
              side={<>{['Available', 'Unavailable'].includes(b.status) ? (
                <label className="flex cursor-pointer items-center gap-2 text-sm font-medium"><input type="checkbox" className="peer sr-only" checked={b.available} onChange={() => toggle(b)} />
                  <span className="relative h-6 w-11 rounded-full bg-slate-300 transition peer-checked:bg-emerald-500 after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:transition peer-checked:after:translate-x-5" />{b.available ? 'Available' : 'Hidden'}</label>
              ) : <span className="text-xs text-slate-500">Active exchange</span>}
                <button className="btn-ghost !py-1 !text-rose-600" onClick={() => remove(b)}>Remove</button></>}>
              <div className="flex items-center gap-2"><StatusBadge status={b.status} /><span className="text-xs font-bold text-slate-500">{b.courseCode}</span></div>
              <p className="truncate font-semibold">{b.title}</p><p className="text-xs text-slate-500">{b.author} · {b.edition} · {b.condition}</p>
            </Row>
          ))}
        </>)}

        {loaded && tab === 'history' && (<>
          {!history.length && <Empty icon="🕑" title="No history yet" hint="Completed exchanges show up here." />}
          {history.map((r) => {
            const mineReviewed = r.reviewedBy.includes(user.id);
            return (
              <Row key={r.id} cover={<Cover book={r.book} className="h-full w-full" />}
                side={r.status === 'Returned' ? (mineReviewed ? <span className="text-sm text-emerald-700">✓ You rated {who(r).name}</span> : <div className="text-right"><p className="text-xs text-slate-500">Rate {who(r).name}'s punctuality</p><Stars value={0} onChange={(n) => rate(r.id, n)} /></div>) : null}>
                <StatusBadge status={r.status} /><p className="truncate font-semibold">{r.book.title}</p>
                <p className="text-xs text-slate-500">{r.lenderId === user.id ? 'Lent to ' + r.borrower.name : 'Borrowed from ' + r.lender.name} · {fmtDate(r.returnedAt || r.requestedAt)}{r.status === 'Returned' && (r.onTime ? ' · on time' : ' · late')}</p>
              </Row>
            );
          })}
        </>)}
      </div>
      {chat && <ChatPanel request={chat} onClose={() => setChat(null)} />}
    </div>
  );
}
