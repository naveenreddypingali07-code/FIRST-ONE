import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { useApp } from '../context';
import { Modal } from './ui';

export default function ChatPanel({ request, onClose }) {
  const { user, toast } = useApp();
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const end = useRef();
  const other = request.lenderId === user.id ? request.borrower : request.lender;
  useEffect(() => {
    let stop = false;
    const load = () => api.get('/requests/' + request.id + '/messages').then((m) => !stop && setMsgs((p) => (p.length === m.length ? p : m))).catch(() => {});
    load(); const t = setInterval(load, 2000);
    return () => { stop = true; clearInterval(t); };
  }, [request.id]);
  useEffect(() => end.current?.scrollIntoView({ behavior: 'smooth' }), [msgs.length]);
  const send = async (e, preset) => {
    e?.preventDefault();
    const t = (preset || text).trim(); if (!t) return;
    setText('');
    try { const m = await api.post('/requests/' + request.id + '/messages', { text: t }); setMsgs((p) => [...p, m]); } catch (er) { toast(er.message, 'error'); }
  };
  const quick = ['Library main entrance?', 'Canteen at 4pm?', 'Department office?', 'Running 10 min late'];
  return (
    <Modal title={'Chat with ' + other.name + ' · ' + request.book.title} onClose={onClose}>
      <div className="flex h-[55vh] flex-col">
        <div className="flex-1 space-y-2 overflow-y-auto rounded-xl bg-slate-50 p-3">
          {!msgs.length && <p className="py-8 text-center text-sm text-slate-400">Coordinate a handoff spot on campus. Messages update live.</p>}
          {msgs.map((m) => (
            <div key={m.id} className={'flex ' + (m.senderId === user.id ? 'justify-end' : 'justify-start')}>
              <div className={'max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ' + (m.senderId === user.id ? 'bg-vault-600 text-white' : 'bg-white shadow-sm')}>
                {m.text}<div className={'mt-0.5 text-[10px] ' + (m.senderId === user.id ? 'text-vault-100' : 'text-slate-400')}>{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            </div>
          ))}
          <div ref={end} />
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">{quick.map((q) => <button key={q} onClick={() => send(null, q)} className="rounded-full border border-slate-300 px-2.5 py-1 text-xs hover:bg-slate-100">{q}</button>)}</div>
        <form onSubmit={send} className="mt-2 flex gap-2">
          <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message…" maxLength={500} />
          <button className="btn-primary">Send</button>
        </form>
      </div>
    </Modal>
  );
}
