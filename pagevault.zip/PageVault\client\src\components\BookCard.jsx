import { Cover, StatusBadge, TrustChip } from './ui';

export default function BookCard({ book, onOpen, mine }) {
  return (
    <button onClick={() => onOpen(book)} className="card group flex h-full flex-col overflow-hidden text-left transition hover:-translate-y-1 hover:shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-vault-500">
      <div className="relative aspect-[5/6] overflow-hidden bg-slate-100">
        <Cover book={book} className="h-full w-full transition group-hover:scale-105" />
        <div className="absolute left-2 top-2"><StatusBadge status={book.status} /></div>
        <span className="absolute bottom-2 right-2 rounded-md bg-slate-900/80 px-2 py-0.5 text-xs font-bold text-white">{book.courseCode}</span>
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3.5">
        <h3 className="line-clamp-2 font-semibold leading-snug text-slate-900">{book.title}</h3>
        <p className="line-clamp-1 text-sm text-slate-500">{book.author} · {book.edition} ed.</p>
        <div className="mt-auto flex items-center justify-between pt-2 text-xs text-slate-500">
          <span className="rounded bg-slate-100 px-1.5 py-0.5">{book.condition}</span>
          {mine ? <span className="font-medium text-vault-600">Your book</span> : <span className="truncate pl-2">{book.owner?.name}</span>}
        </div>
        {!mine && <TrustChip trust={book.owner?.trust} />}
      </div>
    </button>
  );
}
