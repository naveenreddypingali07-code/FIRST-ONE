import { useEffect, useState } from 'react';
import { NavLink, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { api } from './api';
import { useApp } from './context';
import { DEPARTMENTS, timeAgo } from './utils';
import Catalog from './pages/Catalog';
import ListBook from './pages/ListBook';
import Dashboard from './pages/Dashboard';
import Wishlist from './pages/Wishlist';

function Login() {
  const { login, toast } = useApp();
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', department: DEPARTMENTS[0] });
  useEffect(() => { api.get('/users').then(setUsers).catch(() => toast('Cannot reach the server. Is it running on port 4000?', 'error')); }, [toast]);
  const create = async (e) => {
    e.preventDefault();
    try { const u = await api.post('/users', form); await login(u.id); } catch (er) { toast(er.message, 'error'); }
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-vault-900 via-vault-700 to-sky-500 p-4">
      <div className="card w-full max-w-4xl overflow-hidden md:grid md:grid-cols-2">
        <div className="bg-vault-900 p-8 text-white">
          <div className="text-4xl">📚</div>
          <h1 className="mt-3 text-3xl font-extrabold">PageVault</h1>
          <p className="mt-1 text-vault-100">OpenShelf · the campus textbook exchange</p>
          <ul className="mt-6 space-y-2 text-sm text-indigo-100">
            <li>✔ List the textbooks you no longer use</li><li>✔ Find any book by course code, e.g. CS201</li>
            <li>✔ Borrow from peers with a 7-day return clock</li><li>✔ Automatic due-date reminders</li>
          </ul>
        </div>
        <div className="p-8">
          <h2 className="font-bold">Continue as a demo student</h2>
          <p className="text-xs text-slate-500">Open two browser windows and sign in as two students to try the full flow.</p>
          <div className="mt-3 grid gap-2">
            {users.map((u) => (
              <button key={u.id} onClick={() => login(u.id)} className="flex items-center gap-3 rounded-xl border border-slate-200 p-2.5 text-left hover:border-vault-500 hover:bg-vault-50">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-vault-100 font-bold text-vault-700">{u.name[0]}</span>
                <span><span className="block text-sm font-semibold">{u.name}</span><span className="text-xs text-slate-500">{u.department}</span></span>
              </button>
            ))}
          </div>
          <form onSubmit={create} className="mt-5 border-t pt-4">
            <h2 className="font-bold">Or create your profile</h2>
            <div className="mt-2 grid gap-2">
              <input className="input" placeholder="Your name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              <select className="input" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}>{DEPARTMENTS.map((d) => <option key={d}>{d}</option>)}</select>
              <button className="btn-primary">Join campus</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

function Bell() {
  const { notifications, markRead } = useApp();
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const unread = notifications.filter((n) => !n.read).length;
  return (
    <div className="relative">
      <button onClick={() => { setOpen(!open); if (!open && unread) markRead(); }} className="relative rounded-full p-2 hover:bg-slate-100" aria-label="Notifications">
        <span className="text-xl">🔔</span>
        {unread > 0 && <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[11px] font-bold text-white">{unread}</span>}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-40 mt-2 max-h-96 w-80 overflow-y-auto rounded-xl border bg-white shadow-xl">
            <div className="border-b px-4 py-2 text-sm font-bold">Notifications</div>
            {!notifications.length && <p className="p-6 text-center text-sm text-slate-400">Nothing yet</p>}
            {notifications.map((n) => (
              <button key={n.id} onClick={() => { setOpen(false); nav(n.type === 'wishlist' ? '/' : '/dashboard'); }} className="block w-full border-b px-4 py-2.5 text-left text-sm last:border-0 hover:bg-slate-50">
                <p className={n.read ? 'text-slate-600' : 'font-semibold'}>{n.message}</p><span className="text-xs text-slate-400">{timeAgo(n.createdAt)}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function ReminderBanners() {
  const { reminders } = useApp();
  const nav = useNavigate();
  const [perm, setPerm] = useState('Notification' in window ? Notification.permission : 'denied');
  const [hidden, setHidden] = useState([]);
  const list = reminders.filter((r) => !hidden.includes(r.requestId + r.level));
  return (
    <div className="space-y-2">
      {perm === 'default' && reminders.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-sky-50 px-4 py-2 text-sm text-sky-900 ring-1 ring-sky-200">
          Turn on browser alerts so you never miss a return date.
          <button className="btn-primary !py-1" onClick={() => Notification.requestPermission().then(setPerm)}>Enable alerts</button>
        </div>
      )}
      {list.map((r) => (
        <div key={r.requestId + r.level} role="alert" className={'flex items-start justify-between gap-3 rounded-xl px-4 py-2.5 text-sm font-medium ring-1 ' + (r.level === 'soon' ? 'bg-amber-50 text-amber-900 ring-amber-300' : 'bg-rose-50 text-rose-900 ring-rose-300')}>
          <button className="text-left" onClick={() => nav('/dashboard')}>{r.level === 'soon' ? '⏰' : '🚨'} {r.message}</button>
          <button onClick={() => setHidden([...hidden, r.requestId + r.level])} aria-label="Dismiss" className="opacity-60 hover:opacity-100">✕</button>
        </div>
      ))}
    </div>
  );
}

function Shell() {
  const { user, logout, toasts } = useApp();
  const [users, setUsers] = useState([]);
  const { login } = useApp();
  useEffect(() => { api.get('/users').then(setUsers).catch(() => {}); }, []);
  const link = ({ isActive }) => 'rounded-lg px-3 py-1.5 text-sm font-semibold ' + (isActive ? 'bg-vault-100 text-vault-700' : 'text-slate-600 hover:bg-slate-100');
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-4 py-2.5">
          <NavLink to="/" className="mr-3 flex items-center gap-2 text-lg font-extrabold text-vault-900"><span className="text-2xl">📚</span> PageVault</NavLink>
          <nav className="flex flex-1 flex-wrap gap-1">
            <NavLink to="/" end className={link}>Browse</NavLink><NavLink to="/list" className={link}>List a Book</NavLink>
            <NavLink to="/dashboard" className={link}>My Exchanges</NavLink><NavLink to="/wishlist" className={link}>Wishlist</NavLink>
          </nav>
          <Bell />
          <select aria-label="Switch student" value={user.id} onChange={(e) => login(e.target.value)} className="rounded-lg border border-slate-300 bg-white py-1.5 pl-2 pr-6 text-sm font-medium">
            {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
          <button onClick={logout} className="btn-ghost !py-1.5">Sign out</button>
        </div>
      </header>
      <main className="mx-auto max-w-7xl space-y-4 px-4 py-6">
        <ReminderBanners />
        <Routes>
          <Route path="/" element={<Catalog />} /><Route path="/list" element={<ListBook />} />
          <Route path="/dashboard" element={<Dashboard />} /><Route path="/wishlist" element={<Wishlist />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      <footer className="py-8 text-center text-xs text-slate-400">PageVault · OpenShelf Challenge · built for students, by students</footer>
      <div className="pointer-events-none fixed bottom-4 right-4 z-[60] space-y-2">
        {toasts.map((t) => <div key={t.id} role="status" className={'pointer-events-auto max-w-sm rounded-xl px-4 py-3 text-sm font-medium text-white shadow-lg ' + (t.type === 'error' ? 'bg-rose-600' : t.type === 'success' ? 'bg-emerald-600' : 'bg-slate-800')}>{t.message}</div>)}
      </div>
    </div>
  );
}

export default function App() {
  const { user, ready } = useApp();
  if (!ready) return <div className="flex min-h-screen items-center justify-center text-slate-400">Loading…</div>;
  return user ? <Shell /> : <Login />;
}
