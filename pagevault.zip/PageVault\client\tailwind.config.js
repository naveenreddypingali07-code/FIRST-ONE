export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { vault: { 50: '#eef2ff', 100: '#e0e7ff', 500: '#6366f1', 600: '#4f46e5', 700: '#4338ca', 900: '#1e1b4b' } } } },
  plugins: [],
};
