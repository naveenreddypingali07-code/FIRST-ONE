let userId = localStorage.getItem('pv-user') || '';
export const setApiUser = (id) => { userId = id || ''; id ? localStorage.setItem('pv-user', id) : localStorage.removeItem('pv-user'); };
export const getStoredUser = () => localStorage.getItem('pv-user') || '';

async function call(method, url, body) {
  const res = await fetch('/api' + url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(userId && { 'x-user-id': userId }) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(data.error || 'Something went wrong'); e.fields = data.errors; e.status = res.status; throw e; }
  return data;
}
export const api = {
  get: (u) => call('GET', u),
  post: (u, b) => call('POST', u, b || {}),
  patch: (u, b) => call('PATCH', u, b),
  del: (u) => call('DELETE', u),
};
