import { useEffect, useRef, useState } from 'react';

// ISBN barcode scanner using the browser camera + QuaggaJS. Loaded lazily to keep the main bundle small.
export default function Scanner({ onDetected, onClose }) {
  const box = useRef();
  const [err, setErr] = useState('');
  useEffect(() => {
    let Quagga, active = true, handled = false;
    (async () => {
      try {
        Quagga = (await import('@ericblade/quagga2')).default;
        await Quagga.init({ inputStream: { type: 'LiveStream', target: box.current, constraints: { facingMode: 'environment' } }, decoder: { readers: ['ean_reader'] }, locate: true }, (e) => {
          if (e) { setErr('Camera unavailable: ' + (e.message || e.name || e) + '. You can type the ISBN instead.'); return; }
          if (active) Quagga.start();
        });
        Quagga.onDetected((r) => {
          const code = r.codeResult.code;
          if (handled || !/^97[89]\d{10}$/.test(code)) return; // only valid ISBN-13 barcodes
          handled = true; onDetected(code);
        });
      } catch (e) { setErr('Scanner failed to load: ' + e.message); }
    })();
    return () => { active = false; try { Quagga?.offDetected(); Quagga?.stop(); } catch {} };
  }, [onDetected]);
  return (
    <div className="mt-3 overflow-hidden rounded-xl border border-slate-300 bg-black">
      <div ref={box} className="relative aspect-video w-full [&>canvas]:absolute [&>canvas]:inset-0 [&>video]:h-full [&>video]:w-full [&>video]:object-cover" />
      <div className="flex items-center justify-between bg-slate-900 px-3 py-2 text-xs text-slate-200">
        <span>{err || 'Point the camera at the barcode on the back cover…'}</span>
        <button type="button" onClick={onClose} className="rounded bg-slate-700 px-2 py-1 hover:bg-slate-600">Close</button>
      </div>
    </div>
  );
}
