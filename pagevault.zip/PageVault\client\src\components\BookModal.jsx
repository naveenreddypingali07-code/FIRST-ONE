import { useState } from 'react';
import { api } from '../api';
import { useApp } from '../context';
import { Cover, Modal, StatusBadge, TrustChip } from './ui';

export default function BookModal({ book, onClose, onChanged }) {
  const { user, toast, refresh } = useApp();
  const [busy, setBusy] = useState(false);
  const mine = book.ownerId === user.id;

  const request = async () => {
    setBusy(true);
    try { await api.post('/requests', { bookId: book.id }); toast('Request sent to ' + book.owner.name + '!', 'success'); refresh(); onChanged(); onClose(); }
    catch (e) { toast(e.message, 'error'); onChanged(); onClose(); }
    finally { setBusy(false); }
  };
  const wish = async () => {
    try { await api.post('/wishlist', { query: book.courseCode }); toast('Added ' + book.courseCode + ' to your wishlist', 'success'); }
    catch (e) { toast(e.message, 'error'); }
  };
  const rows = [['Course', book.courseCode], ['Department', book.department], ['Edition', book.edition], ['Condition', book.condition], ['ISBN', book.isbn || 'Not provided']];
  return (
    <Modal title="Book details" onClose={onClose} wide>
      <div className="grid gap-5 sm:grid-cols-[180px_1fr]">
        <div className="mx-auto w-44 overflow-hidden rounded-xl shadow-lg sm:w-full"><Cover book={book} className="aspect-[5/7] w-full" /></div>
        <div>
          <div className="flex flex-wrap items-center gap-2"><StatusBadge status={book.status} /></div>
          <h3 className="mt-2 text-2xl font-bold leading-tight">{book.title}</h3>
          <p className="text-slate-500">by {book.author}</p>
          <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {rows.map(([k, v]) => <div key={k}><dt className="text-xs uppercase tracking-wide text-slate-400">{k}</dt><dd className="font-medium">{v}</dd></div>)}
          </dl>
          <div className="mt-4 flex items-center gap-3 rounded-xl bg-slate-50 p-3 text-sm">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-vault-100 font-bold text-vault-700">{book.owner?.name[0]}</div>
            <div><div className="font-semibold">{book.owner?.name} <span className="font-normal text-slate-500">· {book.owner?.department}</span></div><TrustChip trust={book.owner?.trust} /></div>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            {mine ? <p className="text-sm text-slate-500">This is your book. Manage it from My Exchanges.</p>
              : book.status === 'Available' ? <button className="btn-primary" disabled={busy} onClick={request}>Request Borrow (7 days)</button>
              : <><button className="btn-ghost" disabled>{book.status === 'Reserved' ? 'Request pending' : 'Currently unavailable'}</button><button className="btn-ghost" onClick={wish}>Alert me when available</button></>}
          </div>
        </div>
      </div>
    </Modal>
  );
}
