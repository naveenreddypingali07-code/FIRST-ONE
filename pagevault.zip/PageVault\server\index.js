import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { get, save, uid, reset } from './db.js';

export const app = express();
app.use(cors());
app.use(express.json());

const DAY = 86400000;
const LOAN_DAYS = 7;
const bad = (res, code, error) => res.status(code).json({ error });
const now = () => new Date().toISOString();

// ---- helpers ---------------------------------------------------------------
const notify = (userId, type, message, extra = {}) => {
  get().notifications.unshift({ id: uid('n'), userId, type, message, read: false, createdAt: now(), ...extra });
};
const user = (id) => get().users.find((u) => u.id === id);
const trust = (userId) => {
  const rs = get().reviews.filter((r) => r.revieweeId === userId);
  const avg = rs.length ? rs.reduce((s, r) => s + r.rating, 0) / rs.length : null;
  return { average: avg ? Math.round(avg * 10) / 10 : null, count: rs.length };
};
const publicUser = (u) => u && ({ id: u.id, name: u.name, department: u.department, email: u.email, trust: trust(u.id) });
const auth = (req, res, next) => {
  const u = user(req.header('x-user-id'));
  if (!u) return bad(res, 401, 'Please sign in first.');
  req.user = u;
  next();
};
// Status is derived: a book is Borrowed/Reserved if an active request says so.
const bookView = (b) => {
  const active = get().requests.find((r) => r.bookId === b.id && (r.status === 'Pending' || r.status === 'Approved'));
  const status = active ? (active.status === 'Approved' ? 'Borrowed' : 'Reserved') : b.available ? 'Available' : 'Unavailable';
  return { ...b, status, owner: publicUser(user(b.ownerId)) };
};
const reqView = (r) => {
  const b = get().books.find((x) => x.id === r.bookId);
  return { ...r, book: b && { id: b.id, title: b.title, author: b.author, courseCode: b.courseCode, isbn: b.isbn },
    lender: publicUser(user(r.lenderId)), borrower: publicUser(user(r.borrowerId)),
    reviewedBy: get().reviews.filter((x) => x.requestId === r.id).map((x) => x.reviewerId) };
};
// Wishlist alerts when a matching book becomes available.
const wishlistAlerts = (book) => {
  for (const w of get().wishlist) {
    if (w.userId === book.ownerId) continue;
    const q = w.query.toLowerCase();
    const hit = book.courseCode.toLowerCase() === q || book.title.toLowerCase().includes(q) || book.isbn === q;
    if (hit) notify(w.userId, 'wishlist', '"' + book.title + '" (' + book.courseCode + ') from your wishlist is now available on campus!', { bookId: book.id });
  }
};

// ---- users -----------------------------------------------------------------
app.get('/api/users', (_q, res) => res.json(get().users.map(publicUser)));
app.post('/api/users', (req, res) => {
  const { name, department, email } = req.body || {};
  if (!name?.trim() || !department?.trim()) return bad(res, 400, 'Name and department are required.');
  const u = { id: uid('u'), name: name.trim(), department: department.trim(), email: (email || name.trim().split(' ')[0].toLowerCase() + '@campus.edu').trim() };
  get().users.push(u); save();
  res.status(201).json(publicUser(u));
});
app.get('/api/users/:id', (req, res) => { const u = user(req.params.id); u ? res.json(publicUser(u)) : bad(res, 404, 'User not found.'); });

// ---- books -----------------------------------------------------------------
app.get('/api/books', (req, res) => {
  const q = (req.query.q || '').toString().trim().toLowerCase();
  const { status, department } = req.query;
  let list = get().books.map(bookView);
  if (q) list = list.filter((b) => [b.title, b.author, b.courseCode, b.department, b.isbn].some((f) => f.toLowerCase().includes(q)));
  if (department && department !== 'All') list = list.filter((b) => b.department === department);
  if (status && status !== 'All') list = list.filter((b) => b.status === status);
  list.sort((a, b) => (q && b.courseCode.toLowerCase() === q) - (q && a.courseCode.toLowerCase() === q) || b.createdAt.localeCompare(a.createdAt));
  res.json(list);
});
app.get('/api/departments', (_q, res) => res.json([...new Set(get().books.map((b) => b.department))].sort()));
app.get('/api/books/:id', (req, res) => {
  const b = get().books.find((x) => x.id === req.params.id);
  b ? res.json(bookView(b)) : bad(res, 404, 'Book not found.');
});
const CONDITIONS = ['New', 'Like New', 'Good', 'Fair', 'Poor'];
const validateBook = (b) => {
  const e = {};
  if (!b.title?.trim()) e.title = 'Title is required.';
  if (!b.author?.trim()) e.author = 'Author is required.';
  if (!b.edition?.toString().trim()) e.edition = 'Edition is required.';
  if (!/^[A-Za-z]{2,4}\s?-?\d{3}$/.test((b.courseCode || '').trim())) e.courseCode = 'Use a course code like CS201.';
  if (!b.department?.trim()) e.department = 'Department is required.';
  if (!CONDITIONS.includes(b.condition)) e.condition = 'Pick a condition.';
  if (b.isbn && !/^(\d{10}|\d{13})$/.test(b.isbn.replace(/-/g, ''))) e.isbn = 'ISBN must be 10 or 13 digits.';
  return e;
};
app.post('/api/books', auth, (req, res) => {
  const errors = validateBook(req.body || {});
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Please fix the highlighted fields.', errors });
  const b = req.body;
  const book = { id: uid('b'), title: b.title.trim(), author: b.author.trim(), edition: b.edition.toString().trim(),
    isbn: (b.isbn || '').replace(/-/g, ''), courseCode: b.courseCode.replace(/[\s-]/g, '').toUpperCase(), department: b.department.trim(),
    condition: b.condition, coverUrl: b.coverUrl || '', available: true, ownerId: req.user.id, ownerContact: req.user.email, createdAt: now() };
  get().books.unshift(book);
  wishlistAlerts(book);
  save();
  res.status(201).json(bookView(book));
});
app.patch('/api/books/:id', auth, (req, res) => {
  const b = get().books.find((x) => x.id === req.params.id);
  if (!b) return bad(res, 404, 'Book not found.');
  if (b.ownerId !== req.user.id) return bad(res, 403, 'Only the owner can edit this book.');
  const active = get().requests.some((r) => r.bookId === b.id && ['Pending', 'Approved'].includes(r.status));
  if (typeof req.body.available === 'boolean') {
    if (active) return bad(res, 409, 'This book has an active exchange; finish it first.');
    const was = b.available; b.available = req.body.available;
    if (!was && b.available) wishlistAlerts(b);
  }
  for (const k of ['condition', 'edition']) if (req.body[k]) b[k] = req.body[k];
  save();
  res.json(bookView(b));
});
app.delete('/api/books/:id', auth, (req, res) => {
  const d = get(); const b = d.books.find((x) => x.id === req.params.id);
  if (!b) return bad(res, 404, 'Book not found.');
  if (b.ownerId !== req.user.id) return bad(res, 403, 'Only the owner can remove this book.');
  if (d.requests.some((r) => r.bookId === b.id && ['Pending', 'Approved'].includes(r.status))) return bad(res, 409, 'This book has an active exchange.');
  d.books = d.books.filter((x) => x.id !== b.id); save();
  res.json({ ok: true });
});

// ---- exchange requests: Pending -> Approved -> Returned (or Rejected/Cancelled) --------
app.post('/api/requests', auth, (req, res) => {
  const b = get().books.find((x) => x.id === req.body?.bookId);
  if (!b) return bad(res, 404, 'Book not found.');
  if (b.ownerId === req.user.id) return bad(res, 400, 'You cannot borrow your own book.');
  // Atomic check-and-flip: derived status means the book is instantly Reserved for everyone else.
  if (bookView(b).status !== 'Available') return bad(res, 409, 'Sorry, this book is no longer available.');
  const r = { id: uid('r'), bookId: b.id, lenderId: b.ownerId, borrowerId: req.user.id, status: 'Pending',
    loanDays: LOAN_DAYS, requestedAt: now(), approvedAt: null, dueDate: null, returnedAt: null };
  get().requests.unshift(r);
  notify(b.ownerId, 'request', req.user.name + ' wants to borrow "' + b.title + '".', { requestId: r.id });
  save();
  res.status(201).json(reqView(r));
});
app.get('/api/requests', auth, (req, res) => {
  res.json(get().requests.filter((r) => r.lenderId === req.user.id || r.borrowerId === req.user.id).map(reqView));
});
app.patch('/api/requests/:id', auth, (req, res) => {
  const r = get().requests.find((x) => x.id === req.params.id);
  if (!r) return bad(res, 404, 'Request not found.');
  const { action } = req.body || {};
  const b = get().books.find((x) => x.id === r.bookId);
  const isLender = r.lenderId === req.user.id, isBorrower = r.borrowerId === req.user.id;
  if (!isLender && !isBorrower) return bad(res, 403, 'Not your exchange.');
  if (action === 'approve') {
    if (!isLender) return bad(res, 403, 'Only the lender can approve.');
    if (r.status !== 'Pending') return bad(res, 409, 'Request is not pending.');
    r.status = 'Approved'; r.approvedAt = now(); r.dueDate = new Date(Date.now() + r.loanDays * DAY).toISOString();
    notify(r.borrowerId, 'approved', 'Your request for "' + b.title + '" was approved. Return it within ' + r.loanDays + ' days.', { requestId: r.id });
  } else if (action === 'reject') {
    if (!isLender) return bad(res, 403, 'Only the lender can reject.');
    if (r.status !== 'Pending') return bad(res, 409, 'Request is not pending.');
    r.status = 'Rejected';
    notify(r.borrowerId, 'rejected', 'Your request for "' + b.title + '" was declined.', { requestId: r.id });
  } else if (action === 'cancel') {
    if (!isBorrower) return bad(res, 403, 'Only the borrower can cancel.');
    if (r.status !== 'Pending') return bad(res, 409, 'Request is not pending.');
    r.status = 'Cancelled';
    notify(r.lenderId, 'cancelled', user(r.borrowerId).name + ' cancelled the request for "' + b.title + '".', { requestId: r.id });
  } else if (action === 'return') {
    if (!isLender) return bad(res, 403, 'The lender confirms the return.');
    if (r.status !== 'Approved') return bad(res, 409, 'Book is not currently borrowed.');
    r.status = 'Returned'; r.returnedAt = now();
    r.onTime = new Date(r.returnedAt) <= new Date(r.dueDate);
    notify(r.borrowerId, 'returned', '"' + b.title + '" marked as returned. Please rate your lender!', { requestId: r.id });
    if (b.available) wishlistAlerts(b);
  } else if (action === 'extend') {
    if (!isLender || r.status !== 'Approved') return bad(res, 409, 'Only the lender can extend an active loan.');
    r.dueDate = new Date(new Date(r.dueDate).getTime() + 3 * DAY).toISOString();
    notify(r.borrowerId, 'extended', 'Your due date for "' + b.title + '" was extended by 3 days.', { requestId: r.id });
  } else return bad(res, 400, 'Unknown action.');
  save();
  res.json(reqView(r));
});
// Demo helper: time-travel the due date so overdue/upcoming banners can be shown instantly.
app.post('/api/requests/:id/simulate', auth, (req, res) => {
  const r = get().requests.find((x) => x.id === req.params.id);
  if (!r || r.status !== 'Approved') return bad(res, 409, 'Only active loans can be simulated.');
  if (r.lenderId !== req.user.id && r.borrowerId !== req.user.id) return bad(res, 403, 'Not your exchange.');
  const days = Number(req.body?.daysLeft);
  if (!Number.isFinite(days)) return bad(res, 400, 'daysLeft must be a number.');
  r.dueDate = new Date(Date.now() + days * DAY).toISOString(); save();
  res.json(reqView(r));
});

// ---- reminders (computed on read: no cron needed) ----------------------------------
app.get('/api/reminders', auth, (req, res) => {
  const out = [];
  for (const r of get().requests) {
    if (r.status !== 'Approved') continue;
    const left = (new Date(r.dueDate) - Date.now()) / DAY;
    const b = get().books.find((x) => x.id === r.bookId);
    if (r.borrowerId === req.user.id) {
      if (left < 0) out.push({ requestId: r.id, level: 'overdue', message: '"' + b.title + '" is overdue by ' + Math.ceil(-left) + ' day(s). Please return it to ' + user(r.lenderId).name + '.', dueDate: r.dueDate });
      else if (left <= 3) out.push({ requestId: r.id, level: 'soon', message: '"' + b.title + '" is due in ' + (left < 1 ? 'less than a day' : Math.ceil(left) + ' day(s)') + '.', dueDate: r.dueDate });
    } else if (r.lenderId === req.user.id && left < 0) {
      out.push({ requestId: r.id, level: 'lender-overdue', message: user(r.borrowerId).name + ' has not returned "' + b.title + '" (overdue ' + Math.ceil(-left) + ' day(s)).', dueDate: r.dueDate });
    }
  }
  res.json(out);
});

// ---- notifications ------------------------------------------------------------------
app.get('/api/notifications', auth, (req, res) => res.json(get().notifications.filter((n) => n.userId === req.user.id).slice(0, 50)));
app.post('/api/notifications/read', auth, (req, res) => {
  get().notifications.forEach((n) => { if (n.userId === req.user.id) n.read = true; }); save(); res.json({ ok: true });
});

// ---- reviews (peer trust) -----------------------------------------------------------
app.post('/api/reviews', auth, (req, res) => {
  const { requestId, rating } = req.body || {};
  const r = get().requests.find((x) => x.id === requestId);
  if (!r || r.status !== 'Returned') return bad(res, 409, 'You can rate only completed exchanges.');
  if (![r.lenderId, r.borrowerId].includes(req.user.id)) return bad(res, 403, 'Not your exchange.');
  if (!(Number.isInteger(rating) && rating >= 1 && rating <= 5)) return bad(res, 400, 'Rating must be 1 to 5.');
  if (get().reviews.some((x) => x.requestId === r.id && x.reviewerId === req.user.id)) return bad(res, 409, 'Already rated.');
  const revieweeId = req.user.id === r.lenderId ? r.borrowerId : r.lenderId;
  get().reviews.push({ id: uid('rv'), requestId: r.id, reviewerId: req.user.id, revieweeId, rating, createdAt: now() });
  notify(revieweeId, 'review', req.user.name + ' rated your punctuality ' + rating + '/5.');
  save(); res.status(201).json(reqView(r));
});

// ---- chat (polling) -----------------------------------------------------------------
const chatAccess = (req, res) => {
  const r = get().requests.find((x) => x.id === req.params.id);
  if (!r) { bad(res, 404, 'Request not found.'); return null; }
  if (![r.lenderId, r.borrowerId].includes(req.user.id)) { bad(res, 403, 'Not your exchange.'); return null; }
  return r;
};
app.get('/api/requests/:id/messages', auth, (req, res) => {
  if (!chatAccess(req, res)) return;
  res.json(get().messages.filter((m) => m.requestId === req.params.id));
});
app.post('/api/requests/:id/messages', auth, (req, res) => {
  const r = chatAccess(req, res); if (!r) return;
  const text = (req.body?.text || '').trim();
  if (!text) return bad(res, 400, 'Message is empty.');
  const m = { id: uid('m'), requestId: r.id, senderId: req.user.id, text: text.slice(0, 500), createdAt: now() };
  get().messages.push(m);
  notify(req.user.id === r.lenderId ? r.borrowerId : r.lenderId, 'chat', req.user.name + ': ' + m.text.slice(0, 60), { requestId: r.id });
  save(); res.status(201).json(m);
});

// ---- wishlist -----------------------------------------------------------------------
app.get('/api/wishlist', auth, (req, res) => res.json(get().wishlist.filter((w) => w.userId === req.user.id)));
app.post('/api/wishlist', auth, (req, res) => {
  const query = (req.body?.query || '').trim();
  if (!query) return bad(res, 400, 'Enter a course code or title.');
  if (get().wishlist.some((w) => w.userId === req.user.id && w.query.toLowerCase() === query.toLowerCase())) return bad(res, 409, 'Already on your wishlist.');
  const w = { id: uid('w'), userId: req.user.id, query, createdAt: now() };
  get().wishlist.push(w);
  const match = get().books.map(bookView).find((b) => b.status === 'Available' && b.ownerId !== req.user.id && (b.courseCode.toLowerCase() === query.toLowerCase() || b.title.toLowerCase().includes(query.toLowerCase())));
  if (match) notify(req.user.id, 'wishlist', '"' + match.title + '" is already available on campus!', { bookId: match.id });
  save(); res.status(201).json(w);
});
app.delete('/api/wishlist/:id', auth, (req, res) => {
  get().wishlist = get().wishlist.filter((w) => !(w.id === req.params.id && w.userId === req.user.id)); save(); res.json({ ok: true });
});

app.post('/api/reset', (_q, res) => { reset(); res.json({ ok: true }); });
app.get('/api/health', (_q, res) => res.json({ ok: true }));

// ---- serve built frontend if present ---------------------------------------------------
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^\/(?!api).*/, (_q, res) => res.sendFile(path.join(dist, 'index.html')));
}
const PORT = process.env.PORT || 4000;
if (process.argv[1] === fileURLToPath(import.meta.url)) app.listen(PORT, () => console.log('PageVault running on http://localhost:' + PORT));
