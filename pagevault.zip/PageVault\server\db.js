// Tiny relational-style JSON store. Tables: users, books, requests (ExchangeTransactions),
// notifications, reviews, messages, wishlist. Every write is synchronous, and Node runs one
// request handler at a time, so every read-check-write sequence in a route is atomic.
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const dir = path.dirname(fileURLToPath(import.meta.url));
const FILE = process.env.DB_FILE || path.join(dir, 'data', 'db.json');
const seed = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'seed.json'), 'utf8'));
const empty = () => ({ users: seed.users, books: seed.books, requests: [], notifications: [], reviews: [], messages: [], wishlist: [] });
let db;
try { db = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { db = empty(); save(); }
export function save() { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(db, null, 1)); }
export function reset() { db = empty(); save(); return db; }
export const get = () => db;
export const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
