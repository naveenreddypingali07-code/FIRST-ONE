import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context';
import Scanner from '../components/Scanner';
import { Cover } from '../components/ui';
import { CONDITIONS, DEPARTMENTS } from '../utils';

function Field({ k, label, children, hint, errors }) {
  return (
    <label className="block">
      <span className="text-sm font-semibold">{label}</span>
      {children}
      {errors[k] ? <span className="mt-1 block text-xs font-medium text-rose-600">{errors[k]}</span> : hint && <span className="mt-1 block text-xs text-slate-400">{hint}</span>}
    </label>
  );
}

const blank = { title: '', author: '', edition: '', courseCode: '', department: DEPARTMENTS[0], condition: 'Good', isbn: '', coverUrl: '' };

export default function ListBook() {
  const { toast, refresh } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState(blank);
  const [errors, setErrors] = useState({});
  const [scan, setScan] = useState(false);
  const [looking, setLooking] = useState(false);
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setF((p) => ({ ...p, [k]: e.target.value }));

  const lookup = useCallback(async (isbnRaw) => {
    const isbn = (isbnRaw || '').replace(/[^0-9X]/gi, '');
    if (!/^(\d{10}|\d{13})$/.test(isbn)) return toast('Enter a valid 10 or 13 digit ISBN.', 'error');
    setLooking(true);
    try {
      const r = await fetch('https://openlibrary.org/api/books?bibkeys=ISBN:' + isbn + '&format=json&jscmd=data');
      const d = (await r.json())['ISBN:' + isbn];
      if (!d) { toast('No match in Open Library. Fill details manually.', 'info'); setF((p) => ({ ...p, isbn })); return; }
      setF((p) => ({ ...p, isbn, title: d.title + (d.subtitle ? ': ' + d.subtitle : ''), author: (d.authors || []).map((a) => a.name).join(', ') || p.author,
        edition: p.edition || (d.edition_name || '').replace(/\D/g, '') || '1', coverUrl: d.cover?.medium || p.coverUrl }));
      toast('Details auto-filled from Open Library', 'success');
    } catch { toast('Open Library is unreachable (offline?). Fill details manually.', 'error'); }
    finally { setLooking(false); }
  }, [toast]);
  const onDetected = useCallback((code) => { setScan(false); setF((p) => ({ ...p, isbn: code })); lookup(code); }, [lookup]);

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setErrors({});
    try { await api.post('/books', f); toast('Your book is now listed!', 'success'); refresh(); nav('/dashboard'); }
    catch (er) { setErrors(er.fields || {}); toast(er.message, 'error'); }
    finally { setSaving(false); }
  };
  const cls = (k) => 'input mt-1 ' + (errors[k] ? '!border-rose-500' : '');
  return (
    <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-[1fr_260px]">
      <form onSubmit={submit} className="card space-y-4 p-6" noValidate>
        <div><h1 className="text-2xl font-extrabold">List a book</h1><p className="text-sm text-slate-500">Help a classmate and clear your shelf.</p></div>
        <div className="rounded-xl bg-vault-50 p-4">
          <p className="text-sm font-semibold text-vault-700">Quick fill with ISBN</p>
          <div className="mt-2 flex flex-wrap gap-2">
            <input className="input !w-48 flex-1" placeholder="e.g. 9781119800361" value={f.isbn} onChange={set('isbn')} aria-label="ISBN" />
            <button type="button" className="btn-primary" disabled={looking} onClick={() => lookup(f.isbn)}>{looking ? 'Looking up…' : 'Look up'}</button>
            <button type="button" className="btn-ghost" onClick={() => setScan(!scan)}>📷 Scan barcode</button>
          </div>
          {errors.isbn && <span className="mt-1 block text-xs font-medium text-rose-600">{errors.isbn}</span>}
          {scan && <Scanner onDetected={onDetected} onClose={() => setScan(false)} />}
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field errors={errors} k="title" label="Title *"><input className={cls('title')} value={f.title} onChange={set('title')} /></Field>
          <Field errors={errors} k="author" label="Author *"><input className={cls('author')} value={f.author} onChange={set('author')} /></Field>
          <Field errors={errors} k="edition" label="Edition *"><input className={cls('edition')} value={f.edition} onChange={set('edition')} placeholder="e.g. 10th" /></Field>
          <Field errors={errors} k="courseCode" label="Course code *" hint="Letters + 3 digits, e.g. CS201"><input className={cls('courseCode')} value={f.courseCode} onChange={set('courseCode')} placeholder="CS201" /></Field>
          <Field errors={errors} k="department" label="Department *"><select className={cls('department')} value={f.department} onChange={set('department')}>{DEPARTMENTS.map((d) => <option key={d}>{d}</option>)}</select></Field>
          <Field errors={errors} k="condition" label="Condition *"><select className={cls('condition')} value={f.condition} onChange={set('condition')}>{CONDITIONS.map((d) => <option key={d}>{d}</option>)}</select></Field>
        </div>
        <button className="btn-primary w-full !py-2.5" disabled={saving}>{saving ? 'Listing…' : 'List this book'}</button>
      </form>
      <aside className="hidden lg:block">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Live preview</p>
        <div className="card overflow-hidden"><Cover book={{ ...f, id: 'preview', title: f.title || 'Your book title', courseCode: f.courseCode.toUpperCase() || 'CODE', author: f.author || 'Author' }} className="aspect-[5/6] w-full" /></div>
      </aside>
    </div>
  );
}
