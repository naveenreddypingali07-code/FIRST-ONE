export const DAY = 86400000;
export function timeLeft(due, now = Date.now()) {
  const ms = new Date(due).getTime() - now;
  const abs = Math.abs(ms);
  const d = Math.floor(abs / DAY), h = Math.floor((abs % DAY) / 3600000), m = Math.floor((abs % 3600000) / 60000), s = Math.floor((abs % 60000) / 1000);
  // Return status is computed on render by comparing the clock with dueDate (no server cron).
  const level = ms < 0 ? 'overdue' : ms <= 3 * DAY ? 'soon' : 'ok';
  return { ms, overdue: ms < 0, level, text: (d ? d + 'd ' : '') + h + 'h ' + String(m).padStart(2, '0') + 'm ' + String(s).padStart(2, '0') + 's', pct: Math.max(0, Math.min(100, (ms / (7 * DAY)) * 100)) };
}
export const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '-');
export const timeAgo = (iso) => {
  const s = (Date.now() - new Date(iso)) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  return Math.floor(s / 86400) + 'd ago';
};
export const DEPARTMENTS = ['Computer Science', 'Electronics', 'Electrical', 'Mechanical', 'Civil', 'Mathematics', 'Physics', 'Chemistry', 'Biotechnology', 'Other'];
export const CONDITIONS = ['New', 'Like New', 'Good', 'Fair', 'Poor'];
