import { useEffect, useMemo, useState } from 'react';
import { api } from '../api';
import { useApp } from '../context';
import BookCard from '../components/BookCard';
import BookModal from '../components/BookModal';
import { Empty } from '../components/ui';

export default function Catalog() {
  const { user, tick } = useApp();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('All');
  const [dept, setDept] = useState('All');
  const [books, setBooks] = useState(null);
  const [depts, setDepts] = useState([]);
  const [open, setOpen] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api.get('/departments').then(setDepts).catch(() => {}); }, [tick]);
  const load = useMemo(() => () => {
    const p = new URLSearchParams({ q, status, department: dept });
    return api.get('/books?' + p).then((b) => { setBooks(b); setError(''); }).catch((e) => setError(e.message));
  }, [q, status, dept]);
  // Real-time filtering: debounce keystrokes slightly, refetch on any change.
  useEffect(() => { const t = setTimeout(load, 120); return () => clearTimeout(t); }, [load, tick]);
  useEffect(() => { const t = setInterval(load, 8000); return () => clearInterval(t); }, [load]);

  const hot = ['CS201', 'CS301', 'EC201', 'ME101', 'MA101'];
  return (
    <div>
      <section className="rounded-3xl bg-gradient-to-r from-vault-700 to-sky-500 p-6 text-white sm:p-8">
        <h1 className="text-2xl font-extrabold sm:text-3xl">Find your textbook. Skip the markup.</h1>
        <p className="mt-1 text-indigo-100">Search by course code, title, author or department. Borrow from a peer for 7 days.</p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Try CS301, Operating Systems, Mechanical…" aria-label="Search books"
            className="w-full flex-1 rounded-xl border-0 px-4 py-3 text-slate-900 shadow focus:ring-2 focus:ring-white" />
          <select aria-label="Department" value={dept} onChange={(e) => setDept(e.target.value)} className="rounded-xl border-0 px-3 py-3 text-slate-900 shadow"><option>All</option>{depts.map((d) => <option key={d}>{d}</option>)}</select>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <span className="opacity-80">Popular:</span>{hot.map((h) => <button key={h} onClick={() => setQ(h)} className="rounded-full bg-white/20 px-2.5 py-1 font-semibold hover:bg-white/30">{h}</button>)}
        </div>
      </section>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-1.5" role="tablist">
          {['All', 'Available', 'Reserved', 'Borrowed'].map((s) => (
            <button key={s} onClick={() => setStatus(s)} role="tab" aria-selected={status === s} className={'rounded-full px-3.5 py-1.5 text-sm font-semibold ring-1 ' + (status === s ? 'bg-vault-600 text-white ring-vault-600' : 'bg-white text-slate-600 ring-slate-300 hover:bg-slate-100')}>{s}</button>
          ))}
        </div>
        <span className="text-sm text-slate-500">{books ? books.length + ' book' + (books.length === 1 ? '' : 's') : 'Loading…'}</span>
      </div>

      <div className="mt-4">
        {error && <p className="mb-3 rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
        {!books ? (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">{Array.from({ length: 10 }).map((_, i) => <div key={i} className="card aspect-[3/4] animate-pulse bg-slate-200" />)}</div>
        ) : !books.length ? (
          <Empty icon="🔍" title="No books match your search" hint="Nobody has listed it yet. Add it to your wishlist and we will alert you."> 
            {q && <button className="btn-primary" onClick={() => api.post('/wishlist', { query: q }).then(() => alert('Added to wishlist!')).catch((e) => alert(e.message))}>Add “{q}” to wishlist</button>}
          </Empty>
        ) : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {books.map((b) => <BookCard key={b.id} book={b} mine={b.ownerId === user.id} onOpen={setOpen} />)}
          </div>
        )}
      </div>
      {open && <BookModal book={open} onClose={() => setOpen(null)} onChanged={load} />}
    </div>
  );
}
