import { useEffect, useState } from 'react';
import { timeLeft } from '../utils';

const HUES = [243, 199, 160, 340, 28, 280, 12, 190];
const hue = (s) => HUES[[...s].reduce((a, c) => a + c.charCodeAt(0), 0) % HUES.length];

// Book cover: Open Library image by ISBN; falls back to a generated SVG showing title + course code.
export function Cover({ book, className = '' }) {
  const [failed, setFailed] = useState(false);
  const src = book.coverUrl || (book.isbn ? 'https://covers.openlibrary.org/b/isbn/' + book.isbn + '-M.jpg?default=false' : '');
  useEffect(() => setFailed(false), [src]);
  if (src && !failed) {
    return <img src={src} alt={'Cover of ' + book.title} loading="lazy" onError={() => setFailed(true)}
      onLoad={(e) => { if (e.target.naturalWidth < 20) setFailed(true); }} className={'object-cover ' + className} />;
  }
  const h = hue(book.courseCode + book.title);
  const words = book.title.split(' ');
  const lines = []; let cur = '';
  words.forEach((wd) => { if ((cur + ' ' + wd).trim().length > 16) { lines.push(cur); cur = wd; } else cur = (cur + ' ' + wd).trim(); });
  lines.push(cur);
  return (
    <svg viewBox="0 0 200 280" role="img" aria-label={'Cover of ' + book.title} className={className} preserveAspectRatio="xMidYMid slice">
      <defs><linearGradient id={'g' + h + book.id} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={'hsl(' + h + ',70%,38%)'} /><stop offset="1" stopColor={'hsl(' + ((h + 40) % 360) + ',70%,22%)'} /></linearGradient></defs>
      <rect width="200" height="280" fill={'url(#g' + h + book.id + ')'} />
      <rect x="14" y="0" width="6" height="280" fill="rgba(255,255,255,.18)" />
      <rect x="34" y="30" width="132" height="26" rx="13" fill="rgba(255,255,255,.2)" />
      <text x="100" y="48" textAnchor="middle" fill="#fff" fontSize="15" fontWeight="700" fontFamily="sans-serif">{book.courseCode}</text>
      {lines.slice(0, 5).map((l, i) => <text key={i} x="100" y={110 + i * 24} textAnchor="middle" fill="#fff" fontSize="17" fontWeight="600" fontFamily="Georgia,serif">{l}</text>)}
      <text x="100" y="258" textAnchor="middle" fill="rgba(255,255,255,.75)" fontSize="11" fontFamily="sans-serif">{(book.author || '').slice(0, 30)}</text>
    </svg>
  );
}

const BADGE = {
  Available: 'bg-emerald-100 text-emerald-800 ring-emerald-300',
  Borrowed: 'bg-rose-100 text-rose-800 ring-rose-300',
  Reserved: 'bg-amber-100 text-amber-800 ring-amber-300',
  Unavailable: 'bg-slate-200 text-slate-600 ring-slate-300',
  Pending: 'bg-amber-100 text-amber-800 ring-amber-300',
  Approved: 'bg-sky-100 text-sky-800 ring-sky-300',
  Returned: 'bg-emerald-100 text-emerald-800 ring-emerald-300',
  Rejected: 'bg-slate-200 text-slate-600 ring-slate-300',
  Cancelled: 'bg-slate-200 text-slate-600 ring-slate-300',
};
export function StatusBadge({ status }) {
  const dot = { Available: 'bg-emerald-500', Borrowed: 'bg-rose-500', Reserved: 'bg-amber-500' }[status] || 'bg-slate-400';
  return <span className={'inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ' + (BADGE[status] || BADGE.Unavailable)}>
    <span className={'h-1.5 w-1.5 rounded-full ' + dot} />{status}</span>;
}

export function useNow(ms = 1000) {
  const [n, setN] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setN(Date.now()), ms); return () => clearInterval(t); }, [ms]);
  return n;
}

export function Countdown({ due }) {
  const now = useNow();
  const t = timeLeft(due, now);
  const color = t.level === 'overdue' ? 'bg-rose-500' : t.level === 'soon' ? 'bg-amber-500' : 'bg-emerald-500';
  const txt = t.level === 'overdue' ? 'text-rose-700' : t.level === 'soon' ? 'text-amber-700' : 'text-emerald-700';
  return (
    <div aria-live="off">
      <div className={'text-sm font-bold tabular-nums ' + txt}>{t.overdue ? 'Overdue by ' + t.text : t.text + ' left'}</div>
      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
        <div className={'h-full rounded-full transition-all ' + color} style={{ width: (t.overdue ? 100 : t.pct) + '%' }} />
      </div>
    </div>
  );
}

export function Stars({ value = 0, onChange, size = 'text-xl' }) {
  const [hover, setHover] = useState(0);
  return (
    <span className={'inline-flex ' + size} role={onChange ? 'radiogroup' : 'img'} aria-label={value + ' out of 5 stars'}>
      {[1, 2, 3, 4, 5].map((i) => (
        <button key={i} type="button" disabled={!onChange} onClick={() => onChange?.(i)} onMouseEnter={() => onChange && setHover(i)} onMouseLeave={() => setHover(0)}
          className={(i <= (hover || Math.round(value)) ? 'text-amber-400' : 'text-slate-300') + (onChange ? ' hover:scale-110' : ' cursor-default')} aria-label={i + ' star'}>★</button>
      ))}
    </span>
  );
}

export function TrustChip({ trust }) {
  if (!trust?.count) return <span className="text-xs text-slate-400">No ratings yet</span>;
  return <span className="inline-flex items-center gap-1 text-xs text-slate-600"><Stars value={trust.average} size="text-sm" /> {trust.average} ({trust.count})</span>;
}

export function Modal({ onClose, title, children, wide }) {
  useEffect(() => {
    const k = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k); document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = ''; };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 backdrop-blur-sm sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={'max-h-[92vh] w-full overflow-y-auto rounded-t-2xl bg-white shadow-2xl sm:rounded-2xl ' + (wide ? 'max-w-3xl' : 'max-w-lg')}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-5 py-3">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-slate-500 hover:bg-slate-100" aria-label="Close">✕</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export const Empty = ({ icon = '📭', title, hint, children }) => (
  <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-12 text-center">
    <div className="text-4xl">{icon}</div>
    <p className="mt-2 font-semibold text-slate-700">{title}</p>
    {hint && <p className="mt-1 text-sm text-slate-500">{hint}</p>}
    {children && <div className="mt-4">{children}</div>}
  </div>
);
