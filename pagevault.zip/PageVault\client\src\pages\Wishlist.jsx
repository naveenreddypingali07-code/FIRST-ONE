import { useEffect, useState } from 'react';
import { api } from '../api';
import { useApp } from '../context';
import { Empty } from '../components/ui';

export default function Wishlist() {
  const { toast, tick } = useApp();
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  const load = () => api.get('/wishlist').then(setItems);
  useEffect(() => { load(); }, [tick]);
  const add = async (e) => {
    e.preventDefault();
    try { await api.post('/wishlist', { query: q }); setQ(''); toast('Added! We will alert you when it is listed.', 'success'); load(); } catch (er) { toast(er.message, 'error'); }
  };
  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-2xl font-extrabold">Campus wishlist</h1>
      <p className="text-sm text-slate-500">Tell us what you need. When a matching book becomes available anywhere on campus, you get an instant alert.</p>
      <form onSubmit={add} className="mt-4 flex gap-2"><input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Course code or title, e.g. CS401" /><button className="btn-primary">Add</button></form>
      <div className="mt-4 space-y-2">
        {!items.length && <Empty icon="⭐" title="Your wishlist is empty" hint="Add a course code to get started." />}
        {items.map((i) => (
          <div key={i.id} className="card flex items-center justify-between px-4 py-3"><span className="font-semibold">{i.query}</span>
            <button className="text-sm text-rose-600 hover:underline" onClick={() => api.del('/wishlist/' + i.id).then(load)}>Remove</button></div>
        ))}
      </div>
    </div>
  );
}
