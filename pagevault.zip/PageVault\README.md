# PageVault: OpenShelf Challenge

Campus-wide peer-to-peer textbook exchange. Students list books, search by course code, request borrowings, and get automated 7-day return reminders.

**Stack:** React 18 + React Router + Tailwind CSS (Vite) � Node.js + Express � JSON relational store � Open Library API � QuaggaJS

## Quick start (about 1 minute)

Requires Node.js 18+.

```bash
npm run setup     # installs server + client deps and builds the UI
npm start         # http://localhost:4000  (API and UI together)
```

The built UI is already included in `client/dist`, so you can also just run:
`cd server && npm install && npm start`.

Dev mode with hot reload (two terminals): `cd server && npm start` and `cd client && npm install && npm run dev` (http://localhost:5173).

Run the automated end-to-end API test: `npm test`.

## 2-minute demo script (matches the brief)

1. Open http://localhost:4000 and continue as **Aarav Sharma** (Student A). Go to **List a Book** and add "Operating System Concepts (Galvin)" with course code `CS301`.
   Try the ISBN box (`9781119800361`, then Look up) to see Open Library auto-fill, or ?? Scan barcode.
2. Open a second browser window (or use the student switcher in the header) and sign in as **Diya Patel** (Student B). Search `CS301`. The book badge shows **Available**. Click it, then **Request Borrow**. The badge becomes **Reserved** for everyone.
3. Back as Student A: **My Exchanges > Incoming requests > Approve**. Badge flips to **Borrowed**.
4. As Student B: **My Exchanges > Borrowed by me** shows the live 7-day countdown. Click **Simulate overdue** to trigger the reminder banner and browser alert instantly.
5. Student A clicks **Mark returned**. Badge returns to **Available**. Both can rate punctuality (1-5 stars) under **History**.

## Features

Core (all implemented)
- **Book listing and cataloging**: title, author, edition, course code, department, condition, availability toggle. Validation on client and server; live cover preview.
- **Course-aware search**: course code / title / author / department / ISBN, real-time filtering plus department and status filters. Exact course-code matches rank first.
- **3-state borrow workflow**: Pending, Approved, Returned (plus Reject and Cancel).
- **Availability badge**: Available / Reserved / Borrowed, always derived from the live request state.
- **Due-date reminders**: banners plus browser Notification API for "due soon" (3 days or less) and "overdue". No cron job: status is computed from `dueDate` on every render and read.
- **My Exchanges dashboard**: borrowed (with live countdown bars), incoming requests, lent out, listed books, history.

Stretch (all implemented)
- **ISBN barcode scanner** (QuaggaJS, lazy-loaded) with Open Library auto-fill.
- **Peer trust rating** (1-5 stars, shown on book cards and requests).
- **Lender-borrower chat** (live polling, quick-reply handoff locations).
- **Campus wishlist** with instant alerts when a matching book is listed or returned.

Extras: notification bell, demo student switcher, due-date extension (+3 days), SVG fallback covers, skeleton loaders, empty states, keyboard and screen-reader friendly modals, responsive layout.

## Key engineering decisions (from the brief's challenges)

| Challenge | Solution |
|---|---|
| Deadlines without cron | Reminders derived on read from `dueDate`; countdown ticks client-side every second |
| Double-borrow | Request creation checks status and creates the Pending record in one synchronous step. Node handles one request at a time, so this is atomic, and the book is immediately Reserved. Covered by a test |
| Missing covers | `Cover` component tries Open Library by ISBN, then falls back to a generated SVG with title and course code |

## Data model (server/db.js)

`users`, `books`, `requests` (exchange transactions), `notifications`, `reviews`, `messages`, `wishlist`. Seeded with 35 engineering and science textbooks (`server/data/seed.json`). Data persists in `server/data/db.json`; delete it to reset, or `POST /api/reset`.

## API

`GET/POST /api/books` � `PATCH/DELETE /api/books/:id` � `POST /api/requests` � `PATCH /api/requests/:id {action: approve|reject|cancel|return|extend}` � `GET /api/reminders` � `GET /api/notifications` � `POST /api/reviews` � `GET/POST /api/requests/:id/messages` � `GET/POST/DELETE /api/wishlist` � `GET/POST /api/users`

Authentication is intentionally lightweight (pick a student, sent as `x-user-id`) for demo purposes; a real deployment would use campus SSO.

## Deploy (Render, free)
1. Push this folder to a GitHub repo.
2. On render.com choose New > Blueprint (or Web Service), pick the repo. render.yaml sets build (npm run setup) and start (npm start).
3. Open the generated https://pagevault.onrender.com link. The free tier sleeps after idle (first load ~30s) and data resets on redeploy, which is fine for a demo.
