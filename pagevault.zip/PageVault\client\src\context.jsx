import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { api, getStoredUser, setApiUser } from './api';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [tick, setTick] = useState(0); // bump to make pages refetch after changes
  const seen = useRef(new Set());

  const toast = useCallback((message, type = 'info') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);
  const refresh = useCallback(() => setTick((t) => t + 1), []);

  const login = useCallback(async (id) => {
    setApiUser(id);
    try { setUser(await api.get('/users/' + id)); } catch { setApiUser(''); setUser(null); }
  }, []);
  const logout = useCallback(() => { setApiUser(''); setUser(null); setReminders([]); setNotifications([]); seen.current = new Set(); }, []);

  useEffect(() => { const id = getStoredUser(); (id ? login(id) : Promise.resolve()).finally(() => setReady(true)); }, [login]);

  // Poll reminders + notifications. Reminders are derived from dueDate on every read.
  useEffect(() => {
    if (!user) return;
    let stop = false;
    const poll = async () => {
      try {
        const [rem, notes] = await Promise.all([api.get('/reminders'), api.get('/notifications')]);
        if (stop) return;
        setReminders(rem);
        setNotifications((prev) => {
          const prevIds = new Set(prev.map((n) => n.id));
          if (prev.length) notes.filter((n) => !prevIds.has(n.id) && !n.read).forEach((n) => toast(n.message, 'info'));
          return notes;
        });
        const today = new Date().toDateString();
        rem.forEach((r) => {
          const key = r.requestId + r.level + today;
          if (seen.current.has(key)) return;
          seen.current.add(key);
          if ('Notification' in window && Notification.permission === 'granted') new Notification('PageVault reminder', { body: r.message });
        });
        // Let open pages pick up status changes made by the other party.
        if (prev_len.current !== notes.length) { prev_len.current = notes.length; refresh(); }
      } catch { /* offline: ignore */ }
    };
    const prev_len = { current: -1 };
    poll();
    const t = setInterval(poll, 5000);
    return () => { stop = true; clearInterval(t); };
  }, [user, toast, refresh]);

  const markRead = async () => { await api.post('/notifications/read'); setNotifications((n) => n.map((x) => ({ ...x, read: true }))); };

  return (
    <Ctx.Provider value={{ user, ready, login, logout, toast, toasts, reminders, notifications, markRead, tick, refresh }}>
      {children}
    </Ctx.Provider>
  );
}
